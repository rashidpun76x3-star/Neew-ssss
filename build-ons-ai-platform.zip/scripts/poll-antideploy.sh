#!/bin/bash
set -e

DEVICE_CODE=$(node -e 'console.log(require("/tmp/ad-device-code.json").deviceCode)')
INTERVAL=$(node -e 'console.log(require("/tmp/ad-device-code.json").interval || 5)')

mkdir -p ~/.antideploy

for i in $(seq 1 12); do
  RESP=$(curl -sS -X POST https://antideploy.com/api/v1/device/token \
    -H 'content-type: application/json' \
    -d "{\"deviceCode\":\"$DEVICE_CODE\"}")
  
  ERROR=$(echo "$RESP" | node -e 'let d="";process.stdin.on("data",c=>d+=c);process.stdin.on("end",()=>{try{const j=JSON.parse(d);console.log(j.error||"")}catch(e){console.log("")}})')
  
  if [ "$ERROR" = "authorization_pending" ]; then
    sleep $INTERVAL
    continue
  elif [ -n "$ERROR" ]; then
    echo "Auth error: $ERROR" > /tmp/ad-auth-status.txt
    exit 1
  fi

  # Success 200: capture token and write to ~/.antideploy/config.json
  echo "$RESP" | node -e '
    let d="";process.stdin.on("data",c=>d+=c);process.stdin.on("end",()=>{
      const j=JSON.parse(d);
      const fs=require("fs");
      const path=require("path");
      const confPath=path.join(process.env.HOME, ".antideploy", "config.json");
      fs.writeFileSync(confPath, JSON.stringify({ token: j.token }), { mode: 0o600 });
      fs.writeFileSync("/tmp/ad-auth-success.json", JSON.stringify({ account: j.account }));
    });
  '
  echo "Approved" > /tmp/ad-auth-status.txt
  exit 0
done

echo "Pending" > /tmp/ad-auth-status.txt
