# ONS AI Super Platform – Deployment Guide

## Overview
**ONS AI** is an enterprise-grade AI Super Platform featuring multi-provider model routing (OpenAI, Claude, Gemini, DeepSeek, Groq, OpenRouter, Qwen, GLM, MiniMax, Custom), 18 functional AI production tools, autonomous agent swarms, and administrative API management with AES-256-GCM encryption.

---

## 1. Antideploy & Cloud Quickstart

### Prerequisites
- Node.js 20+ / 22+
- PostgreSQL database instance
- Docker (optional for containerized deployment)

### Environment Variables
Copy `.env.example` to `.env` and configure:

```bash
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
ENCRYPTION_SECRET=ons-ai-super-platform-secret-32b!
PORT=3000
NODE_ENV=production
```

### Installation & Build
```bash
npm install
npm run build
npm start
```

---

## 2. Docker Deployment

Build and run using the included multi-stage `Dockerfile`:

```bash
docker build -t ons-ai-platform .
docker run -p 3000:3000 \
  -e DATABASE_URL="postgresql://user:pass@host:5432/db" \
  -e ENCRYPTION_SECRET="your-32-character-secret-key!" \
  ons-ai-platform
```

---

## 3. Database Schema & Auto-Seeding

The database automatically initializes and seeds on first startup or through the `/api/health` healthcheck endpoint:
- **Default Administrator Account:**
  - **Email:** `admin@ons.ai`
  - **Password:** `admin123`
- **Demo User Account:**
  - **Email:** `demo@ons.ai`
  - **Password:** `demo123`
- **Pre-configured Foundation Providers:**
  - OpenAI, Anthropic Claude, Google Gemini, DeepSeek, Groq, OpenRouter, Alibaba Qwen, Zhipu GLM, MiniMax, and Custom Provider.
- **Autonomous Agents:**
  - Dr. Evelyn Vance (Chief Research Scientist)
  - Marcus Vance (Principal Cloud & AI Architect)
  - Sienna Ray (Brand Strategist & Viral Copywriter)
  - Nova Vision (Creative Director)

To push Drizzle schema changes directly:
```bash
npx drizzle-kit push
```

---

## 4. Health-Check Endpoint

Monitor deployment health via:
`GET /api/health`

**Expected Response (HTTP 200):**
```json
{
  "status": "healthy",
  "service": "ONS AI Super Platform",
  "version": "2.4.0",
  "timestamp": "2026-03-31T00:00:00.000Z",
  "database": "connected",
  "multiProvider": "active"
}
```

---

## 5. Security & Encryption
- API keys added through **Admin Dashboard > API Management** are encrypted using **AES-256-GCM** with authenticated verification tags before persistence.
- Keys are strictly accessed server-side and masked (`sk-proj••••4242`) in all administrative previews.
- Sessions are stored in PostgreSQL and delivered via HTTP-only, secure cookies.
