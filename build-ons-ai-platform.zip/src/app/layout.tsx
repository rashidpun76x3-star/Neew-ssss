import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "ONS AI – Complete AI Super Platform",
  description:
    "All-in-one autonomous AI Super Platform featuring multi-model chat, 18+ AI production tools, autonomous AI agents, enterprise API management, and real-time analytics.",
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body className="antialiased min-h-screen selection:bg-purple-500 selection:text-white">
        {children}
      </body>
    </html>
  );
}
