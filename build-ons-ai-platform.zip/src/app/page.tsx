"use client";

import React, { useState, useEffect } from "react";
import { Navbar } from "@/components/Navbar";
import { Sidebar } from "@/components/Sidebar";
import { OverviewView } from "@/components/OverviewView";
import { ChatView } from "@/components/ChatView";
import { ToolsView } from "@/components/ToolsView";
import { AgentsView } from "@/components/AgentsView";
import { ProjectsView } from "@/components/ProjectsView";
import { AdminView } from "@/components/AdminView";
import { SettingsView } from "@/components/SettingsView";
import { AuthModal } from "@/components/AuthModal";

export default function ONSAIPlatform() {
  const [currentUser, setCurrentUser] = useState<any | null>(null);
  const [currentView, setCurrentView] = useState("overview");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [conversations, setConversations] = useState<any[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [loadingInitial, setLoadingInitial] = useState(true);

  // Fetch current user and session
  const fetchCurrentUser = async () => {
    try {
      const res = await fetch("/api/auth/me");
      const data = await res.json();
      if (data.authenticated && data.user) {
        setCurrentUser(data.user);
      } else {
        // Auto-initialize demo session if none exists so users can immediately test all features
        try {
          const autoRes = await fetch("/api/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email: "admin@ons.ai", password: "admin123" }),
          });
          const autoData = await autoRes.json();
          if (autoData.success && autoData.user) {
            setCurrentUser(autoData.user);
          }
        } catch (e) {
          console.error("Auto-login error:", e);
        }
      }
    } catch (err) {
      console.error("fetchCurrentUser error:", err);
    } finally {
      setLoadingInitial(false);
    }
  };

  // Fetch conversations
  const fetchConversations = async () => {
    try {
      const res = await fetch("/api/conversations");
      const data = await res.json();
      if (data.conversations) {
        setConversations(data.conversations);
        if (data.conversations.length > 0 && !activeConversationId) {
          setActiveConversationId(data.conversations[0].id);
        }
      }
    } catch (err) {
      console.error("fetchConversations error:", err);
    }
  };

  useEffect(() => {
    fetchCurrentUser();
    fetchConversations();
  }, []);

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      setCurrentUser(null);
      setConversations([]);
      setActiveConversationId(null);
      setCurrentView("overview");
    } catch (err) {
      console.error("Logout error:", err);
    }
  };

  const handleNewConversation = async () => {
    try {
      const res = await fetch("/api/conversations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: "New Conversation" }),
      });
      const data = await res.json();
      if (data.conversation) {
        setConversations((prev) => [data.conversation, ...prev]);
        setActiveConversationId(data.conversation.id);
        setCurrentView("chat");
      }
    } catch (err) {
      console.error("New conversation error:", err);
    }
  };

  const handleDeleteConversation = async (id: string) => {
    try {
      await fetch(`/api/conversations?id=${id}`, { method: "DELETE" });
      setConversations((prev) => prev.filter((c) => c.id !== id));
      if (activeConversationId === id) {
        const remaining = conversations.filter((c) => c.id !== id);
        setActiveConversationId(remaining.length > 0 ? remaining[0].id : null);
      }
    } catch (err) {
      console.error("Delete conversation error:", err);
    }
  };

  if (loadingInitial) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 space-y-4">
        <div className="relative">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 p-1 animate-pulse">
            <div className="w-full h-full bg-slate-950 rounded-xl flex items-center justify-center">
              <span className="font-extrabold text-xl text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400">
                ONS
              </span>
            </div>
          </div>
        </div>
        <div className="text-center space-y-1">
          <h1 className="text-white font-bold text-lg tracking-tight">ONS AI Super Platform</h1>
          <p className="text-slate-500 text-xs font-mono">Initializing multi-model foundation engines...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      {/* Top Navigation */}
      <Navbar
        currentUser={currentUser}
        currentView={currentView}
        onViewChange={setCurrentView}
        onOpenAuth={() => setAuthModalOpen(true)}
        onLogout={handleLogout}
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        activeModel={
          currentView === "chat"
            ? "GPT-4o / Claude 3.5 / DeepSeek"
            : "Multi-Model Router"
        }
      />

      {/* Main Body with Sidebar + Viewport */}
      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          currentView={currentView}
          onViewChange={setCurrentView}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          conversations={conversations}
          activeConversationId={activeConversationId}
          onSelectConversation={(id) => {
            setActiveConversationId(id);
            setCurrentView("chat");
          }}
          onNewConversation={handleNewConversation}
          onDeleteConversation={handleDeleteConversation}
          currentUser={currentUser}
        />

        {/* Primary Content Viewport */}
        <main className="flex-1 overflow-y-auto px-4 md:px-8 py-6 max-w-7xl mx-auto w-full">
          {currentView === "overview" && (
            <OverviewView
              onViewChange={setCurrentView}
              currentUser={currentUser}
              onOpenAuth={() => setAuthModalOpen(true)}
            />
          )}

          {currentView === "chat" && (
            <ChatView
              conversations={conversations}
              activeConversationId={activeConversationId}
              onSelectConversation={setActiveConversationId}
              onNewConversation={handleNewConversation}
              onDeleteConversation={handleDeleteConversation}
              onViewChange={setCurrentView}
              currentUser={currentUser}
            />
          )}

          {currentView === "tools" && (
            <ToolsView
              currentUser={currentUser}
              onProjectSaved={() => fetchConversations()}
            />
          )}

          {currentView === "agents" && <AgentsView currentUser={currentUser} />}

          {currentView === "projects" && <ProjectsView currentUser={currentUser} />}

          {currentView === "admin" && <AdminView currentUser={currentUser} />}

          {currentView === "settings" && (
            <SettingsView
              currentUser={currentUser}
              onProfileUpdated={() => fetchCurrentUser()}
            />
          )}
        </main>
      </div>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={(user) => {
          setCurrentUser(user);
          fetchConversations();
        }}
      />
    </div>
  );
}
