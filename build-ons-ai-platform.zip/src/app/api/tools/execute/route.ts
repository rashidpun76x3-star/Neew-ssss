import { NextRequest, NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { executeAICompletion, ChatMessage } from "@/lib/ai-service";
import { db } from "@/db";
import { projects, userSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import crypto from "crypto";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const user = await getSessionUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { toolKey, inputs, providerSlug, modelId, saveToProjects, projectTitle } = body;

    if (!toolKey || !inputs) {
      return NextResponse.json({ error: "toolKey and inputs are required" }, { status: 400 });
    }

    // Get user's custom API key if configured
    const [settings] = await db
      .select()
      .from(userSettings)
      .where(eq(userSettings.userId, user.id))
      .limit(1);

    const userApiKey = settings?.customApiKey || undefined;

    let systemPrompt = "You are an elite specialized ONS AI tool engine.";
    let userPrompt = "";

    // Route tool-specific prompts
    switch (toolKey) {
      // --- AI Writing ---
      case "blog_generator":
        systemPrompt = "You are a master SEO content strategist and viral blog writer. Produce comprehensive, well-structured, engaging markdown articles with headers, bullet points, key takeaways, and FAQs.";
        userPrompt = `Write a high-ranking, engaging blog post about: "${inputs.topic || "AI Automation"}". Target audience: ${inputs.audience || "Tech professionals"}. Desired tone: ${inputs.tone || "Authoritative & Inspiring"}. Target length: ${inputs.length || "1,200 words"}.`;
        break;

      case "email_writer":
        systemPrompt = "You are an executive communications specialist. Write persuasive, crisp, high-conversion emails with clear subject lines and compelling calls to action.";
        userPrompt = `Write an email for the following purpose: "${inputs.purpose || "Product Launch Pitch"}". Recipient: ${inputs.recipient || "Prospective Client"}. Tone: ${inputs.tone || "Professional & Persuasive"}. Key points to include: ${inputs.keyPoints || "Value proposition, ROI, call to schedule demo"}.`;
        break;

      case "article_writer":
        systemPrompt = "You are a senior investigative journalist and academic writer. Craft deep, factual, highly articulated articles with deep analytical rigor.";
        userPrompt = `Write an in-depth analytical feature article titled/about: "${inputs.title || "The Autonomous AI Paradigm"}". Include historical context, current state, future outlook, and potential ethical/operational risks.`;
        break;

      case "text_summarizer":
        systemPrompt = "You are an expert executive summarizer. Condense text into key takeaways, core findings, bulleted insights, and action items without losing nuance.";
        userPrompt = `Summarize the following text in ${inputs.format || "Executive Brief with Action Items"}:\n\n${inputs.text || ""}`;
        break;

      // --- AI Image ---
      case "text_to_image":
        systemPrompt = "You are a master AI prompt engineer and creative director for Midjourney, DALL-E 3, and Stable Diffusion. Generate highly descriptive, photorealistic prompts, lighting details, camera lens, color grading, and negative prompts, plus SVG visual code.";
        userPrompt = `Generate a master visual concept and detailed diffusion prompt for: "${inputs.prompt || "Cyberpunk Neon Laboratory"}". Style: ${inputs.style || "Photorealistic 8K Cinematic"}. Aspect ratio: ${inputs.aspectRatio || "16:9"}. Include artistic composition breakdown, color palette hex codes, and rendering settings.`;
        break;

      case "image_editing":
        systemPrompt = "You are an advanced digital image processing and generative inpainting director.";
        userPrompt = `Provide a comprehensive image editing & transformation roadmap for: "${inputs.description || "Portrait photo"}". Requested modifications: "${inputs.modifications || "Enhance lighting, remove background artifacts, color grade to cinematic teal and orange"}".`;
        break;

      case "image_understanding":
        systemPrompt = "You are an expert computer vision and multimodal visual analysis model. Analyze visual details, compositions, typography, semantics, and object positioning.";
        userPrompt = `Perform a comprehensive visual analysis for the image description or context: "${inputs.imageContext || "Enterprise SaaS Dashboard screenshot"}". Break down: 1) Visual Composition & Layout, 2) Color Harmony, 3) Key Focal Points, 4) Perceived Strengths, 5) UX/Aesthetic Recommendations.`;
        break;

      // --- AI Video ---
      case "text_to_video":
        systemPrompt = "You are a Hollywood-grade AI video director and cinematographer. Break down video concepts into scene-by-scene prompts, camera pans, lighting transitions, sound design, and frame rates.";
        userPrompt = `Generate a complete 4-scene video production script and AI video generation prompts for: "${inputs.prompt || "Futuristic AI Supercomputer Awakening"}". Style: ${inputs.style || "Sci-Fi IMAX Cinematic"}. Duration: ${inputs.duration || "15 seconds"}.`;
        break;

      case "image_to_video":
        systemPrompt = "You are an AI video animator and motion graphics director. Specify optical flow, camera dolly/tilt, parallax layers, and temporal consistency prompts.";
        userPrompt = `Create an animation and motion design specification for an image of: "${inputs.sourceImage || "A majestic alpine mountain range at twilight"}". Desired motion: "${inputs.motion || "Slow drone zoom-in, volumetric mist drifting, golden hour rays shimmering"}".`;
        break;

      // --- AI Voice ---
      case "text_to_speech":
        systemPrompt = "You are an acoustic director and voice synthesis architect. Generate natural, phonetically tuned SSML (Speech Synthesis Markup Language) and spoken narration scripts.";
        userPrompt = `Generate a voiceover script with SSML tags (prosody, pitch, pauses) for: "${inputs.text || "Welcome to ONS AI. The next era of autonomous computing begins now."}". Desired voice persona: ${inputs.voicePersona || "Deep, resonant executive narrator"}.`;
        break;

      case "speech_to_text":
        systemPrompt = "You are a state-of-the-art speech transcription and audio intelligence processor. Format transcripts cleanly with speaker diarization, punctuation, and sentiment analysis.";
        userPrompt = `Simulate and process accurate audio transcription and intelligence for audio content describing: "${inputs.audioContext || "Quarterly strategic review meeting discussing AI agent roadmap and cloud budgets"}". Include timestamps, speaker labels, key decisions, and sentiment index.`;
        break;

      case "voice_assistant":
        systemPrompt = "You are ONS Voice, a warm, hyper-intelligent, concise, spoken voice AI assistant. Keep responses punchy, conversational, and ideal for audio playback.";
        userPrompt = `Respond conversationally to this spoken voice inquiry: "${inputs.voiceQuery || "What are the latest breakthroughs in multi-agent orchestration?"}".`;
        break;

      // --- AI Development ---
      case "code_generator":
        systemPrompt = "You are a Principal Software Engineer. Write clean, production-ready, type-safe, bug-free code with error handling, documentation, and explanations.";
        userPrompt = `Write a complete, production-grade implementation of: "${inputs.description || "A resilient rate limiter with Redis sliding window algorithm"}". Language/Framework: ${inputs.language || "TypeScript / Next.js"}. Special constraints: ${inputs.constraints || "Strict typing, zero external dependencies"}.`;
        break;

      case "code_debugger":
        systemPrompt = "You are an expert security researcher and elite code debugger. Find bugs, memory leaks, security vulnerabilities, edge cases, and provide corrected code.";
        userPrompt = `Debug, optimize, and secure the following code snippet:\n\`\`\`\n${inputs.code || "function process(arr) { return arr.map(x => x * 2); }"}\n\`\`\`\nProvide: 1) Detected Issues/Vulnerabilities, 2) Corrected Code, 3) Performance Benchmarks, 4) Unit Test Suggestions.`;
        break;

      case "website_generator":
        systemPrompt = "You are a world-class Frontend Engineer and UI/UX Designer. Generate a complete, standalone, gorgeous HTML5/TailwindCSS page ready for immediate browser rendering.";
        userPrompt = `Generate a complete, fully styled, single-file HTML page using Tailwind CSS CDN for: "${inputs.prompt || "Modern AI Cloud SaaS Landing Page"}". Include hero section, features grid, pricing table, and interactive CTA buttons. Return clean HTML code enclosed in \`\`\`html ... \`\`\`.`;
        break;

      // --- AI Documents ---
      case "pdf_reader":
      case "pdf_chat":
        systemPrompt = "You are an intelligent document analyst. Extract semantic structure, critical data points, tabular insights, and answer queries with exact citations.";
        userPrompt = `Document Context/Excerpts:\n"${inputs.documentText || "This report outlines Q4 financial results showing 42% YoY ARR growth, customer acquisition cost reduction of 18%, and net revenue retention of 134%."}"\n\nQuestion/Instruction: "${inputs.query || "Summarize all financial metrics and strategic growth drivers."}"`;
        break;

      case "document_summarizer":
        systemPrompt = "You are an expert technical and legal document summarizer.";
        userPrompt = `Summarize this document:\n\n${inputs.documentText || "ONS AI Whitepaper on Sovereign Compute Architecture..."}\n\nFormat required: ${inputs.format || "Structured Executive Summary, Key Risks, and Operational Checklist"}.`;
        break;

      // --- AI Research ---
      case "web_search":
      case "research_assistant":
        systemPrompt = "You are a Principal Research Analyst with deep real-time web research capabilities. Synthesize facts, contrast viewpoints, verify claims, and provide citations.";
        userPrompt = `Conduct in-depth comprehensive research on: "${inputs.query || "Comparative benchmarks of DeepSeek-R1 vs OpenAI o1 in mathematical reasoning"}". Provide: Executive Overview, Technical Deep-Dive, Empirical Findings, Limitations, and Future Trajectory.`;
        break;

      case "translator":
        systemPrompt = "You are a master polyglot translator and localization specialist. Translate with natural native idiom, cultural precision, and tonal fidelity.";
        userPrompt = `Translate the following text to ${inputs.targetLanguage || "Spanish (Neutral)"}:\n\n"${inputs.text || "Empowering developers worldwide with unified autonomous intelligence."}"\n\nTone: ${inputs.tone || "Professional and Inspiring"}. Also provide: 1) Literal vs Culturally Adapted translations, 2) Vocabulary Breakdown, 3) Formality notes.`;
        break;

      default:
        userPrompt = `Execute analysis for: ${JSON.stringify(inputs)}`;
    }

    const messages: ChatMessage[] = [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt },
    ];

    const result = await executeAICompletion(messages, {
      providerSlug: providerSlug || "openai",
      modelId: modelId || "gpt-4o",
      userId: user.id,
      userApiKey,
      toolType: toolKey,
    });

    let savedProject = null;
    if (saveToProjects) {
      const [proj] = await db
        .insert(projects)
        .values({
          id: crypto.randomUUID(),
          userId: user.id,
          title: projectTitle || `${toolKey.replace(/_/g, " ").toUpperCase()} Output`,
          description: `Generated via ONS AI ${toolKey}`,
          toolType: toolKey,
          content: result.content,
          metadata: JSON.stringify({ model: result.modelUsed, provider: result.providerUsed }),
        })
        .returning();
      savedProject = proj;
    }

    return NextResponse.json({
      success: true,
      result: result.content,
      modelUsed: result.modelUsed,
      providerUsed: result.providerUsed,
      isFallback: result.isFallback,
      setupInstructions: result.setupInstructions,
      savedProject,
    });
  } catch (err: any) {
    console.error("Tool execution error:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
