import { db } from "@/db";
import { sql } from "drizzle-orm";
import { ensureDatabaseSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    await ensureDatabaseSeeded();
    return Response.json({
      status: "healthy",
      service: "ONS AI Super Platform",
      version: "2.4.0",
      timestamp: new Date().toISOString(),
      database: "connected",
      multiProvider: "active",
    });
  } catch (err: any) {
    console.error("Healthcheck error:", err);
    return Response.json({ status: "unhealthy", error: err?.message }, { status: 500 });
  }
}
