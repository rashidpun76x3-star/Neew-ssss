import { NextRequest, NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { db } from "@/db";
import { agents, userSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { executeAICompletion, ChatMessage } from "@/lib/ai-service";

export const dynamic = "force-dynamic";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getSessionUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const [agent] = await db.select().from(agents).where(eq(agents.id, id)).limit(1);

    if (!agent) {
      return NextResponse.json({ error: "Agent not found" }, { status: 404 });
    }

    const body = await req.json();
    const { task, providerSlug, modelId } = body;

    if (!task) {
      return NextResponse.json({ error: "Task description is required" }, { status: 400 });
    }

    const [settings] = await db
      .select()
      .from(userSettings)
      .where(eq(userSettings.userId, user.id))
      .limit(1);

    const toolsList = agent.tools ? JSON.parse(agent.tools) : ["web_search", "code_generator"];

    const prompt = `You are ${agent.name}, an autonomous AI Agent with the role: "${agent.role}".
Your core instructions:
${agent.systemPrompt}

You have access to these internal tools: [${toolsList.join(", ")}].

Execute the following user mission:
"${task}"

Format your response clearly using this structured Agent Execution Framework:
### 1. 🧠 Agent Thought & Strategy
Explain your internal reasoning, decomposition of the task, and planned methodology.

### 2. ⚡ Tool Invocations & Action Steps
Detail the simulated tool actions taken (e.g. searching databases, running code verification, extracting documents).

### 3. 🔍 Observations & Findings
Present the data, facts, and intermediate findings gathered during tool execution.

### 4. 🎯 Final Executive Deliverable
Deliver the completed, production-grade output or strategic recommendation for the user.`;

    const messages: ChatMessage[] = [
      { role: "system", content: agent.systemPrompt },
      { role: "user", content: prompt },
    ];

    const result = await executeAICompletion(messages, {
      providerSlug: providerSlug || "openai",
      modelId: modelId || "gpt-4o",
      userId: user.id,
      userApiKey: settings?.customApiKey || undefined,
      toolType: "agent_runner",
    });

    return NextResponse.json({
      success: true,
      agent: {
        id: agent.id,
        name: agent.name,
        role: agent.role,
        avatar: agent.avatar,
      },
      task,
      result: result.content,
      modelUsed: result.modelUsed,
      providerUsed: result.providerUsed,
      isFallback: result.isFallback,
      setupInstructions: result.setupInstructions,
    });
  } catch (err: any) {
    console.error("Agent run error:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
