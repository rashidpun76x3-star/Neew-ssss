import { NextRequest, NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { db } from "@/db";
import { agents } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import crypto from "crypto";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await getSessionUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const list = await db
      .select()
      .from(agents)
      .where(or(eq(agents.userId, user.id), eq(agents.isPublic, true)));

    return NextResponse.json({ agents: list });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getSessionUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { name, avatar, role, description, systemPrompt, tools, memory, isPublic } = body;

    if (!name || !systemPrompt) {
      return NextResponse.json({ error: "Agent name and system prompt are required" }, { status: 400 });
    }

    const id = crypto.randomUUID();
    const [agent] = await db
      .insert(agents)
      .values({
        id,
        userId: user.id,
        name: name.trim(),
        avatar: avatar || "🤖",
        role: role?.trim() || "Autonomous Specialist",
        description: description?.trim() || "",
        systemPrompt: systemPrompt.trim(),
        tools: tools ? JSON.stringify(tools) : JSON.stringify(["web_search", "code_generator"]),
        memory: memory ? JSON.stringify(memory) : JSON.stringify({ state: "initialized" }),
        isPublic: user.role === "admin" ? !!isPublic : false,
      })
      .returning();

    return NextResponse.json({ agent });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const user = await getSessionUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { id, name, avatar, role, description, systemPrompt, tools, memory, isPublic } = body;

    if (!id) {
      return NextResponse.json({ error: "Agent ID required" }, { status: 400 });
    }

    await db
      .update(agents)
      .set({
        ...(name && { name }),
        ...(avatar && { avatar }),
        ...(role && { role }),
        ...(description && { description }),
        ...(systemPrompt && { systemPrompt }),
        ...(tools && { tools: JSON.stringify(tools) }),
        ...(memory && { memory: JSON.stringify(memory) }),
        ...(isPublic !== undefined && user.role === "admin" && { isPublic }),
        updatedAt: new Date(),
      })
      .where(eq(agents.id, id));

    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const user = await getSessionUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ error: "Agent ID required" }, { status: 400 });
    }

    await db.delete(agents).where(eq(agents.id, id));
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
