import { NextRequest, NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { db } from "@/db";
import { conversations, messages, userSettings } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import { executeAICompletion, ChatMessage } from "@/lib/ai-service";
import crypto from "crypto";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const user = await getSessionUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const conversationId = searchParams.get("conversationId");

    if (!conversationId) {
      return NextResponse.json({ error: "conversationId is required" }, { status: 400 });
    }

    const msgs = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(asc(messages.createdAt));

    return NextResponse.json({ messages: msgs });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getSessionUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    let { conversationId, content, providerSlug, modelId, attachments, systemPrompt } = body;

    if (!content || !content.trim()) {
      return NextResponse.json({ error: "Message content cannot be empty" }, { status: 400 });
    }

    // Get user custom key if exists
    const [settings] = await db
      .select()
      .from(userSettings)
      .where(eq(userSettings.userId, user.id))
      .limit(1);

    const userApiKey = settings?.customApiKey || undefined;

    // If no conversationId provided, create a new conversation
    let convRecord;
    if (!conversationId) {
      const convId = crypto.randomUUID();
      const generatedTitle = content.slice(0, 36) + (content.length > 36 ? "..." : "");
      [convRecord] = await db
        .insert(conversations)
        .values({
          id: convId,
          userId: user.id,
          title: generatedTitle,
          modelId: modelId || "gpt-4o",
          providerId: providerSlug || "openai",
          systemPrompt: systemPrompt || null,
        })
        .returning();
      conversationId = convId;
    } else {
      [convRecord] = await db.select().from(conversations).where(eq(conversations.id, conversationId)).limit(1);
    }

    const activeProvider = providerSlug || convRecord?.providerId || "openai";
    const activeModel = modelId || convRecord?.modelId || "gpt-4o";

    // Save User message
    const userMsgId = crypto.randomUUID();
    await db.insert(messages).values({
      id: userMsgId,
      conversationId,
      role: "user",
      content: content.trim(),
      attachments: attachments ? JSON.stringify(attachments) : null,
      model: activeModel,
    });

    // Retrieve previous messages for context
    const previousMsgs = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(asc(messages.createdAt))
      .limit(12);

    const chatHistory: ChatMessage[] = [];

    // System prompt if any
    const sysPrompt = systemPrompt || convRecord?.systemPrompt || "You are ONS AI, the next-generation autonomous AI Super Platform. Answer with high technical depth, elegant formatting, code blocks, and structured analysis.";
    chatHistory.push({ role: "system", content: sysPrompt });

    for (const m of previousMsgs) {
      chatHistory.push({
        role: m.role as "user" | "assistant" | "system",
        content: m.content,
      });
    }

    // Call AI Service
    const aiResult = await executeAICompletion(chatHistory, {
      providerSlug: activeProvider,
      modelId: activeModel,
      userId: user.id,
      userApiKey,
      toolType: "chat",
    });

    // Save Assistant response
    const assistantMsgId = crypto.randomUUID();
    await db.insert(messages).values({
      id: assistantMsgId,
      conversationId,
      role: "assistant",
      content: aiResult.content,
      model: aiResult.modelUsed,
      tokens: aiResult.tokensCompletion,
    });

    // Update conversation timestamp & title if first message
    if (convRecord && convRecord.title === "New Conversation" || convRecord?.title === "New Chat") {
      const updatedTitle = content.slice(0, 36) + (content.length > 36 ? "..." : "");
      await db
        .update(conversations)
        .set({ title: updatedTitle, updatedAt: new Date() })
        .where(eq(conversations.id, conversationId));
    } else {
      await db.update(conversations).set({ updatedAt: new Date() }).where(eq(conversations.id, conversationId));
    }

    return NextResponse.json({
      conversationId,
      userMessage: {
        id: userMsgId,
        role: "user",
        content: content.trim(),
      },
      assistantMessage: {
        id: assistantMsgId,
        role: "assistant",
        content: aiResult.content,
        model: aiResult.modelUsed,
        provider: aiResult.providerUsed,
        isFallback: aiResult.isFallback,
        setupInstructions: aiResult.setupInstructions,
      },
    });
  } catch (err: any) {
    console.error("Chat error:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
