import { NextRequest, NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { db } from "@/db";
import { uploadedFiles } from "@/db/schema";
import crypto from "crypto";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const user = await getSessionUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const formData = await req.formData();
    const file = formData.get("file") as File | null;

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    const fileName = file.name;
    const fileType = file.type || "application/octet-stream";
    const fileSize = file.size;

    // Read file text content if text-based or PDF/markdown/code
    let contentText = "";
    if (
      fileType.includes("text") ||
      fileType.includes("json") ||
      fileType.includes("javascript") ||
      fileType.includes("markdown") ||
      fileType.includes("pdf") ||
      fileName.endsWith(".txt") ||
      fileName.endsWith(".md") ||
      fileName.endsWith(".json") ||
      fileName.endsWith(".ts") ||
      fileName.endsWith(".tsx") ||
      fileName.endsWith(".py") ||
      fileName.endsWith(".pdf")
    ) {
      const buffer = await file.arrayBuffer();
      contentText = Buffer.from(buffer).toString("utf-8");
      // Clean binary garbage if PDF
      if (fileType.includes("pdf") || fileName.endsWith(".pdf")) {
        contentText = contentText.replace(/[\x00-\x08\x0E-\x1F\x7F-\xFF]/g, " ").slice(0, 50000);
      }
    } else {
      contentText = `[Binary file: ${fileName} (${(fileSize / 1024).toFixed(1)} KB)]`;
    }

    const id = crypto.randomUUID();
    const [record] = await db
      .insert(uploadedFiles)
      .values({
        id,
        userId: user.id,
        fileName,
        fileType,
        fileSize,
        contentText: contentText.slice(0, 50000),
      })
      .returning();

    return NextResponse.json({
      success: true,
      file: {
        id: record.id,
        fileName: record.fileName,
        fileType: record.fileType,
        fileSize: record.fileSize,
        snippet: contentText.slice(0, 300),
      },
    });
  } catch (err: any) {
    console.error("Upload error:", err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
