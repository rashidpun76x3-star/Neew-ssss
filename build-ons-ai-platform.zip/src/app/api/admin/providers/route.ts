import { NextRequest, NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { db } from "@/db";
import { aiProviders, aiModels } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import crypto from "crypto";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await getSessionUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const providers = await db.select().from(aiProviders).orderBy(desc(aiProviders.isDefault));
    const models = await db.select().from(aiModels);

    const enriched = providers.map((p) => {
      const pModels = models.filter((m) => m.providerId === p.id);
      return {
        id: p.id,
        name: p.name,
        slug: p.slug,
        baseUrl: p.baseUrl,
        description: p.description,
        isEnabled: p.isEnabled,
        isDefault: p.isDefault,
        hasKey: !!p.apiKeyEncrypted,
        modelsCount: pModels.length,
        models: pModels,
      };
    });

    return NextResponse.json({ providers: enriched });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getSessionUser();
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden: Admin privileges required" }, { status: 403 });
    }

    const body = await req.json();
    const { name, slug, baseUrl, description, defaultModelName, defaultModelId } = body;

    if (!name || !slug || !baseUrl) {
      return NextResponse.json({ error: "Name, slug, and baseUrl are required" }, { status: 400 });
    }

    const cleanSlug = slug.toLowerCase().trim().replace(/[^a-z0-9_-]/g, "");
    const providerId = crypto.randomUUID();

    const [newProvider] = await db
      .insert(aiProviders)
      .values({
        id: providerId,
        name: name.trim(),
        slug: cleanSlug,
        baseUrl: baseUrl.trim(),
        description: description?.trim() || "Custom AI endpoint",
        isEnabled: true,
        isDefault: false,
      })
      .returning();

    // Insert default model if provided
    if (defaultModelId) {
      await db.insert(aiModels).values({
        id: crypto.randomUUID(),
        providerId,
        name: defaultModelName || defaultModelId,
        modelId: defaultModelId,
        contextWindow: 128000,
        supportsVision: true,
        supportsStreaming: true,
        category: "chat",
        isEnabled: true,
      });
    }

    return NextResponse.json({ provider: newProvider });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const user = await getSessionUser();
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden: Admin privileges required" }, { status: 403 });
    }

    const body = await req.json();
    const { id, isEnabled, isDefault, baseUrl, name, description } = body;

    if (!id) {
      return NextResponse.json({ error: "Provider ID required" }, { status: 400 });
    }

    if (isDefault) {
      // Clear previous default
      await db.update(aiProviders).set({ isDefault: false });
    }

    await db
      .update(aiProviders)
      .set({
        ...(isEnabled !== undefined && { isEnabled }),
        ...(isDefault !== undefined && { isDefault }),
        ...(baseUrl && { baseUrl: baseUrl.trim() }),
        ...(name && { name: name.trim() }),
        ...(description !== undefined && { description }),
        updatedAt: new Date(),
      })
      .where(eq(aiProviders.id, id));

    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
