import { NextRequest, NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { hashPassword } from "@/lib/crypto";
import crypto from "crypto";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await getSessionUser();
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const collaborators = await db
      .select({
        id: users.id,
        name: users.name,
        email: users.email,
        role: users.role,
        plan: users.plan,
        status: users.status,
        createdAt: users.createdAt,
      })
      .from(users)
      .where(or(eq(users.role, "admin"), eq(users.role, "collaborator")));

    return NextResponse.json({ collaborators });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getSessionUser();
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const { name, email, role, password } = await req.json();
    if (!name || !email) {
      return NextResponse.json({ error: "Name and email are required" }, { status: 400 });
    }

    const cleanEmail = email.trim().toLowerCase();
    const [existing] = await db.select().from(users).where(eq(users.email, cleanEmail)).limit(1);
    if (existing) {
      return NextResponse.json({ error: "User already exists with this email" }, { status: 409 });
    }

    const newId = crypto.randomUUID();
    const defaultPassword = password || "Collab2026!";

    await db.insert(users).values({
      id: newId,
      name: name.trim(),
      email: cleanEmail,
      passwordHash: hashPassword(defaultPassword),
      role: role === "admin" ? "admin" : "collaborator",
      plan: "Enterprise",
      credits: 50000,
      status: "active",
    });

    return NextResponse.json({
      success: true,
      message: `Collaborator ${name} added successfully. Initial password: ${defaultPassword}`,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
