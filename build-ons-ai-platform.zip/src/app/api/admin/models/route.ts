import { NextRequest, NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { db } from "@/db";
import { aiModels, aiProviders } from "@/db/schema";
import { eq } from "drizzle-orm";
import crypto from "crypto";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await getSessionUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const models = await db
      .select({
        id: aiModels.id,
        name: aiModels.name,
        modelId: aiModels.modelId,
        contextWindow: aiModels.contextWindow,
        supportsVision: aiModels.supportsVision,
        supportsStreaming: aiModels.supportsStreaming,
        category: aiModels.category,
        isEnabled: aiModels.isEnabled,
        providerId: aiModels.providerId,
        providerName: aiProviders.name,
        providerSlug: aiProviders.slug,
      })
      .from(aiModels)
      .innerJoin(aiProviders, eq(aiModels.providerId, aiProviders.id));

    return NextResponse.json({ models });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getSessionUser();
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await req.json();
    const { providerId, name, modelId, contextWindow, supportsVision, supportsStreaming, category } = body;

    if (!providerId || !name || !modelId) {
      return NextResponse.json({ error: "providerId, name, and modelId are required" }, { status: 400 });
    }

    const [model] = await db
      .insert(aiModels)
      .values({
        id: crypto.randomUUID(),
        providerId,
        name: name.trim(),
        modelId: modelId.trim(),
        contextWindow: contextWindow ? Number(contextWindow) : 128000,
        supportsVision: !!supportsVision,
        supportsStreaming: supportsStreaming !== undefined ? !!supportsStreaming : true,
        category: category || "chat",
        isEnabled: true,
      })
      .returning();

    return NextResponse.json({ model });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const user = await getSessionUser();
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await req.json();
    const { id, isEnabled, name, contextWindow, supportsVision, category } = body;

    if (!id) {
      return NextResponse.json({ error: "Model ID required" }, { status: 400 });
    }

    await db
      .update(aiModels)
      .set({
        ...(isEnabled !== undefined && { isEnabled }),
        ...(name && { name: name.trim() }),
        ...(contextWindow && { contextWindow: Number(contextWindow) }),
        ...(supportsVision !== undefined && { supportsVision: !!supportsVision }),
        ...(category && { category }),
      })
      .where(eq(aiModels.id, id));

    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const user = await getSessionUser();
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 });

    await db.delete(aiModels).where(eq(aiModels.id, id));
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
