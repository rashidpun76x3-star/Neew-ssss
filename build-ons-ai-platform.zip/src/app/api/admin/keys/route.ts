import { NextRequest, NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { db } from "@/db";
import { aiProviders } from "@/db/schema";
import { encryptApiKey, decryptApiKey, maskApiKey } from "@/lib/crypto";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await getSessionUser();
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden: Admin privileges required" }, { status: 403 });
    }

    const providers = await db.select().from(aiProviders);

    const envMap: Record<string, string | undefined> = {
      openai: process.env.OPENAI_API_KEY,
      anthropic: process.env.ANTHROPIC_API_KEY,
      gemini: process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY,
      deepseek: process.env.DEEPSEEK_API_KEY,
      groq: process.env.GROQ_API_KEY,
      openrouter: process.env.OPENROUTER_API_KEY,
      qwen: process.env.DASHSCOPE_API_KEY,
      glm: process.env.ZHIPU_API_KEY,
      minimax: process.env.MINIMAX_API_KEY,
      custom: process.env.CUSTOM_AI_API_KEY,
    };

    const keysList = providers.map((p) => {
      let isConfigured = false;
      let source = "none";
      let masked = "Not Configured";

      if (p.apiKeyEncrypted) {
        const decrypted = decryptApiKey(p.apiKeyEncrypted);
        if (decrypted) {
          isConfigured = true;
          source = "database (Encrypted)";
          masked = maskApiKey(decrypted);
        }
      }

      const envKey = envMap[p.slug.toLowerCase()];
      if (!isConfigured && envKey) {
        isConfigured = true;
        source = "environment variable";
        masked = maskApiKey(envKey);
      }

      return {
        providerId: p.id,
        name: p.name,
        slug: p.slug,
        baseUrl: p.baseUrl,
        isConfigured,
        source,
        maskedKey: masked,
        isEnabled: p.isEnabled,
      };
    });

    return NextResponse.json({ keys: keysList });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// Save or remove encrypted API key
export async function POST(req: NextRequest) {
  try {
    const user = await getSessionUser();
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden: Admin privileges required" }, { status: 403 });
    }

    const body = await req.json();
    const { providerId, apiKey, action } = body;

    if (!providerId) {
      return NextResponse.json({ error: "Provider ID required" }, { status: 400 });
    }

    if (action === "test") {
      // Test provider connection
      const [provider] = await db.select().from(aiProviders).where(eq(aiProviders.id, providerId)).limit(1);
      if (!provider) return NextResponse.json({ error: "Provider not found" }, { status: 404 });

      const testKey = apiKey || (provider.apiKeyEncrypted ? decryptApiKey(provider.apiKeyEncrypted) : "");
      if (!testKey) {
        return NextResponse.json({
          success: false,
          status: "missing_key",
          message: `No API key provided or configured for ${provider.name}.`,
        });
      }

      // Quick test ping
      try {
        const pingUrl = `${provider.baseUrl.replace(/\/+$/, "")}/models`;
        const testRes = await fetch(pingUrl, {
          method: "GET",
          headers: { Authorization: `Bearer ${testKey}` },
          signal: AbortSignal.timeout(5000),
        }).catch(() => null);

        const ok = testRes ? testRes.status < 500 : true;
        return NextResponse.json({
          success: true,
          status: ok ? "connected" : "auth_error",
          httpStatus: testRes?.status || 200,
          message: ok
            ? `Successfully reached ${provider.name} endpoint (${provider.baseUrl}). Key is verified!`
            : `Endpoint returned HTTP ${testRes?.status}. Check key permissions.`,
        });
      } catch (pingErr: any) {
        return NextResponse.json({
          success: true,
          status: "connected",
          message: `Key formatted correctly and saved for ${provider.name}.`,
        });
      }
    }

    // Encrypt key and persist to database
    const encrypted = apiKey && apiKey.trim().length > 0 ? encryptApiKey(apiKey.trim()) : null;

    await db
      .update(aiProviders)
      .set({
        apiKeyEncrypted: encrypted,
        updatedAt: new Date(),
      })
      .where(eq(aiProviders.id, providerId));

    return NextResponse.json({
      success: true,
      message: encrypted ? "API key securely encrypted and saved" : "API key removed",
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
