import { NextRequest, NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { db } from "@/db";
import { users, userSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(req: NextRequest) {
  try {
    const user = await getSessionUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { name, avatar, theme, defaultModel, defaultProvider, customApiKey, notifications } = body;

    if (name) {
      await db.update(users).set({ name: name.trim(), avatar, updatedAt: new Date() }).where(eq(users.id, user.id));
    }

    // Update settings
    const [existingSettings] = await db.select().from(userSettings).where(eq(userSettings.userId, user.id)).limit(1);
    if (existingSettings) {
      await db
        .update(userSettings)
        .set({
          theme: theme || existingSettings.theme,
          defaultModel: defaultModel || existingSettings.defaultModel,
          defaultProvider: defaultProvider || existingSettings.defaultProvider,
          customApiKey: customApiKey !== undefined ? customApiKey : existingSettings.customApiKey,
          notifications: notifications !== undefined ? notifications : existingSettings.notifications,
          updatedAt: new Date(),
        })
        .where(eq(userSettings.userId, user.id));
    }

    return NextResponse.json({ success: true, message: "Profile updated successfully" });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
