import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, userSettings } from "@/db/schema";
import { hashPassword } from "@/lib/crypto";
import { createSession } from "@/lib/auth";
import { ensureDatabaseSeeded } from "@/lib/seed";
import { eq } from "drizzle-orm";
import crypto from "crypto";

export async function POST(req: NextRequest) {
  try {
    await ensureDatabaseSeeded();
    const body = await req.json();
    const { name, email, password } = body;

    if (!name || !email || !password) {
      return NextResponse.json({ error: "Name, email, and password are required" }, { status: 400 });
    }

    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail.includes("@") || password.length < 6) {
      return NextResponse.json({ error: "Please provide a valid email and a password of at least 6 characters" }, { status: 400 });
    }

    const [existing] = await db.select().from(users).where(eq(users.email, cleanEmail)).limit(1);
    if (existing) {
      return NextResponse.json({ error: "An account with this email already exists" }, { status: 409 });
    }

    const userId = crypto.randomUUID();
    const passwordHash = hashPassword(password);

    await db.insert(users).values({
      id: userId,
      name: name.trim(),
      email: cleanEmail,
      passwordHash,
      role: "user",
      plan: "Pro",
      credits: 10000,
      status: "active",
    });

    await db.insert(userSettings).values({
      id: crypto.randomUUID(),
      userId,
      theme: "dark",
      defaultModel: "gpt-4o",
      defaultProvider: "openai",
      notifications: true,
    });

    await createSession(userId, req.headers);

    return NextResponse.json({
      success: true,
      user: {
        id: userId,
        name: name.trim(),
        email: cleanEmail,
        role: "user",
        plan: "Pro",
        credits: 10000,
      },
    });
  } catch (err: any) {
    console.error("Signup error:", err);
    return NextResponse.json({ error: err.message || "Failed to register account" }, { status: 500 });
  }
}
