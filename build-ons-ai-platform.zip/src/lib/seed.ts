import { db } from "@/db";
import { users, aiProviders, aiModels, agents, userSettings, projects } from "@/db/schema";
import { hashPassword } from "./crypto";
import { eq } from "drizzle-orm";
import crypto from "crypto";

export async function ensureDatabaseSeeded() {
  try {
    // 1. Check if admin exists
    const [adminUser] = await db.select().from(users).where(eq(users.email, "admin@ons.ai")).limit(1);

    let adminId = adminUser?.id;
    if (!adminUser) {
      adminId = crypto.randomUUID();
      await db.insert(users).values({
        id: adminId,
        name: "ONS AI Administrator",
        email: "admin@ons.ai",
        passwordHash: hashPassword("admin123"),
        role: "admin",
        plan: "Enterprise",
        credits: 999999,
        status: "active",
      });

      await db.insert(userSettings).values({
        id: crypto.randomUUID(),
        userId: adminId,
        theme: "dark",
        defaultModel: "gpt-4o",
        defaultProvider: "openai",
        notifications: true,
      });
    }

    // 2. Check if demo user exists
    const [demoUser] = await db.select().from(users).where(eq(users.email, "demo@ons.ai")).limit(1);
    let demoId = demoUser?.id;
    if (!demoUser) {
      demoId = crypto.randomUUID();
      await db.insert(users).values({
        id: demoId,
        name: "Alex Rivera",
        email: "demo@ons.ai",
        passwordHash: hashPassword("demo123"),
        role: "user",
        plan: "Pro",
        credits: 25000,
        status: "active",
      });

      await db.insert(userSettings).values({
        id: crypto.randomUUID(),
        userId: demoId,
        theme: "dark",
        defaultModel: "gpt-4o",
        defaultProvider: "openai",
        notifications: true,
      });
    }

    // 3. Seed AI Providers
    const providersList = [
      {
        slug: "openai",
        name: "OpenAI",
        baseUrl: "https://api.openai.com/v1",
        description: "GPT-4o, GPT-4o Mini, o1 reasoning models, and DALL-E 3 image generation.",
        isDefault: true,
        models: [
          { name: "GPT-4o (Omni)", modelId: "gpt-4o", context: 128000, vision: true, cat: "chat" },
          { name: "GPT-4o Mini", modelId: "gpt-4o-mini", context: 128000, vision: true, cat: "chat" },
          { name: "o1 Reasoning", modelId: "o1-preview", context: 128000, vision: false, cat: "reasoning" },
          { name: "DALL-E 3 Image", modelId: "dall-e-3", context: 4096, vision: false, cat: "image" },
        ],
      },
      {
        slug: "anthropic",
        name: "Anthropic Claude",
        baseUrl: "https://api.anthropic.com/v1",
        description: "Claude 3.5 Sonnet, Claude 3.5 Haiku, and Claude 3 Opus with leading nuance and code intelligence.",
        isDefault: false,
        models: [
          { name: "Claude 3.5 Sonnet", modelId: "claude-3-5-sonnet-20241022", context: 200000, vision: true, cat: "chat" },
          { name: "Claude 3.5 Haiku", modelId: "claude-3-5-haiku-20241022", context: 200000, vision: true, cat: "chat" },
          { name: "Claude 3 Opus", modelId: "claude-3-opus-20240229", context: 200000, vision: true, cat: "reasoning" },
        ],
      },
      {
        slug: "gemini",
        name: "Google Gemini",
        baseUrl: "https://generativelanguage.googleapis.com/v1beta",
        description: "Gemini 1.5 Pro and 2.0 Flash with massive multi-million context window and vision capabilities.",
        isDefault: false,
        models: [
          { name: "Gemini 1.5 Pro", modelId: "gemini-1.5-pro", context: 1000000, vision: true, cat: "chat" },
          { name: "Gemini 1.5 Flash", modelId: "gemini-1.5-flash", context: 1000000, vision: true, cat: "chat" },
          { name: "Gemini 2.0 Flash", modelId: "gemini-2.0-flash", context: 1000000, vision: true, cat: "reasoning" },
        ],
      },
      {
        slug: "deepseek",
        name: "DeepSeek",
        baseUrl: "https://api.deepseek.com/v1",
        description: "DeepSeek-V3 and DeepSeek-R1 reasoning models engineered for extreme coding, math, and analytical depth.",
        isDefault: false,
        models: [
          { name: "DeepSeek Chat (V3)", modelId: "deepseek-chat", context: 64000, vision: false, cat: "chat" },
          { name: "DeepSeek Reasoner (R1)", modelId: "deepseek-reasoner", context: 64000, vision: false, cat: "reasoning" },
        ],
      },
      {
        slug: "groq",
        name: "Groq",
        baseUrl: "https://api.groq.com/openai/v1",
        description: "Ultra-fast LPU inference engine powering Llama 3.3 70B, Mixtral, and Whisper transcription.",
        isDefault: false,
        models: [
          { name: "Llama 3.3 70B Versatile", modelId: "llama-3.3-70b-versatile", context: 128000, vision: false, cat: "chat" },
          { name: "Mixtral 8x7B 32k", modelId: "mixtral-8x7b-32768", context: 32768, vision: false, cat: "chat" },
        ],
      },
      {
        slug: "openrouter",
        name: "OpenRouter",
        baseUrl: "https://openrouter.ai/api/v1",
        description: "Unified gateway to over 200+ global AI models with smart fallback and routing.",
        isDefault: false,
        models: [
          { name: "OpenRouter Auto Router", modelId: "openrouter/auto", context: 128000, vision: true, cat: "chat" },
          { name: "Llama 3.3 70B (OpenRouter)", modelId: "meta-llama/llama-3.3-70b-instruct", context: 128000, vision: false, cat: "chat" },
        ],
      },
      {
        slug: "qwen",
        name: "Qwen (Alibaba)",
        baseUrl: "https://dashscope.aliyuncs.com/compatible-mode/v1",
        description: "Alibaba Cloud flagship Qwen 2.5 series featuring superior bilingual English & Chinese performance.",
        isDefault: false,
        models: [
          { name: "Qwen 2.5 72B Instruct", modelId: "qwen-2.5-72b-instruct", context: 128000, vision: false, cat: "chat" },
          { name: "Qwen Max", modelId: "qwen-max", context: 128000, vision: false, cat: "reasoning" },
        ],
      },
      {
        slug: "glm",
        name: "GLM (Zhipu AI)",
        baseUrl: "https://open.bigmodel.cn/api/paas/v4",
        description: "Zhipu AI high-performance GLM-4 language and vision foundation models.",
        isDefault: false,
        models: [
          { name: "GLM-4 Plus", modelId: "glm-4-plus", context: 128000, vision: false, cat: "chat" },
          { name: "GLM-4 Flash", modelId: "glm-4-flash", context: 128000, vision: false, cat: "chat" },
        ],
      },
      {
        slug: "minimax",
        name: "MiniMax",
        baseUrl: "https://api.minimax.chat/v1",
        description: "MiniMax multimodal intelligence for generative text, speech synthesis, and video creation.",
        isDefault: false,
        models: [
          { name: "MiniMax abab6.5s", modelId: "abab6.5s-chat", context: 245000, vision: false, cat: "chat" },
          { name: "MiniMax Video-01", modelId: "video-01", context: 4096, vision: true, cat: "image" },
        ],
      },
      {
        slug: "custom",
        name: "Custom API Provider",
        baseUrl: "https://api.custom-ai.example.com/v1",
        description: "Bring your own private endpoint, OpenAI-compatible proxy, or self-hosted vLLM/Ollama server.",
        isDefault: false,
        models: [
          { name: "Custom Model V1", modelId: "custom-model-v1", context: 128000, vision: true, cat: "chat" },
        ],
      },
    ];

    for (const p of providersList) {
      const [existing] = await db.select().from(aiProviders).where(eq(aiProviders.slug, p.slug)).limit(1);
      let providerId = existing?.id;
      if (!existing) {
        providerId = crypto.randomUUID();
        await db.insert(aiProviders).values({
          id: providerId,
          name: p.name,
          slug: p.slug,
          baseUrl: p.baseUrl,
          description: p.description,
          isEnabled: true,
          isDefault: p.isDefault,
        });

        for (const m of p.models) {
          await db.insert(aiModels).values({
            id: crypto.randomUUID(),
            providerId,
            name: m.name,
            modelId: m.modelId,
            contextWindow: m.context,
            supportsVision: m.vision,
            supportsStreaming: true,
            category: m.cat,
            isEnabled: true,
          });
        }
      }
    }

    // 4. Seed Pre-configured Autonomous Agents
    const agentsCount = await db.select().from(agents).limit(1);
    if (agentsCount.length === 0 && (adminId || demoId)) {
      const creatorId = adminId || demoId!;
      const defaultAgents = [
        {
          name: "Dr. Evelyn Vance (Chief Research Scientist)",
          avatar: "🔬",
          role: "Senior Research & Synthesis Agent",
          description: "Synthesizes multi-source research papers, web intel, fact verification, and competitive market dossiers.",
          systemPrompt: "You are Dr. Evelyn Vance, Chief Research Scientist at ONS AI. Your role is to deliver rigorous, source-grounded research summaries, deep-dive academic breakdowns, and strategic industry intelligence. Always state key hypotheses, data points, and executive takeaways.",
          tools: JSON.stringify(["web_search", "document_summarizer", "fact_checker"]),
          isPublic: true,
        },
        {
          name: "Marcus Vance (Principal Cloud & AI Architect)",
          avatar: "⚡",
          role: "Fullstack Engineering & Architecture Agent",
          description: "Generates scalable microservices, Next.js components, database migrations, security audits, and bug fixes.",
          systemPrompt: "You are Marcus Vance, Principal AI & Cloud Architect. You write production-grade, cleanly structured TypeScript, Python, SQL, and Docker configurations. Always emphasize security, performance, clean error boundaries, and modern patterns.",
          tools: JSON.stringify(["code_generator", "code_debugger", "website_generator"]),
          isPublic: true,
        },
        {
          name: "Sienna Ray (Brand Strategist & Viral Copywriter)",
          avatar: "✍️",
          role: "Executive Copy & Conversion Strategist",
          description: "Crafts high-converting landing pages, SEO authority blogs, viral Twitter/LinkedIn threads, and investor emails.",
          systemPrompt: "You are Sienna Ray, high-stakes Copywriter & Brand Strategist. You understand consumer psychology, hook retention, narrative cadence, and high-conversion calls to action. Every piece of copy you write is crisp, persuasive, and rhythmically engaging.",
          tools: JSON.stringify(["blog_generator", "email_writer", "article_writer"]),
          isPublic: true,
        },
        {
          name: "Nova Vision (Multimodal Media Director)",
          avatar: "🎨",
          role: "Creative Concept & Visual Arts Agent",
          description: "Directs photorealistic text-to-image prompts, camera angles, color grading, and video script storyboards.",
          systemPrompt: "You are Nova Vision, a world-class AI visual creative director. You specialize in Midjourney/DALL-E 3 aesthetic prompt craft, lighting specifications, aspect ratios, cinematography, and artistic storytelling.",
          tools: JSON.stringify(["text_to_image", "image_editing", "image_to_video"]),
          isPublic: true,
        },
      ];

      for (const a of defaultAgents) {
        await db.insert(agents).values({
          id: crypto.randomUUID(),
          userId: creatorId,
          name: a.name,
          avatar: a.avatar,
          role: a.role,
          description: a.description,
          systemPrompt: a.systemPrompt,
          tools: a.tools,
          memory: JSON.stringify({ activeContext: "Initialized with high autonomy." }),
          isPublic: a.isPublic,
        });
      }
    }

    // 5. Seed sample projects
    const projectsCount = await db.select().from(projects).limit(1);
    if (projectsCount.length === 0 && (adminId || demoId)) {
      const ownerId = demoId || adminId!;
      const sampleProjects = [
        {
          title: "AI Super Platform Launch Keynote",
          description: "Executive launch deck outline and keynote speech for ONS AI global rollout.",
          toolType: "article",
          content: "# Welcome to ONS AI: The Autonomous Intelligence Era\n\nONS AI represents the convergence of multi-model LLMs, real-time agentic workflows, and multimodal production tools into one unified cloud operating system...",
          metadata: JSON.stringify({ wordCount: 1420, model: "gpt-4o" }),
        },
        {
          title: "Next.js SaaS Authentication Microservice",
          description: "Clean TypeScript JWT & Session Handler with rate limiting and audit logging.",
          toolType: "code",
          content: "import { NextRequest, NextResponse } from 'next/server';\n// ONS AI Secure Session Guard v2.4\nexport async function middleware(req: NextRequest) {\n  const token = req.cookies.get('ons_session')?.value;\n  if (!token) return NextResponse.redirect(new URL('/login', req.url));\n  return NextResponse.next();\n}",
          metadata: JSON.stringify({ language: "typescript" }),
        },
      ];

      for (const p of sampleProjects) {
        await db.insert(projects).values({
          id: crypto.randomUUID(),
          userId: ownerId,
          title: p.title,
          description: p.description,
          toolType: p.toolType,
          content: p.content,
          metadata: p.metadata,
        });
      }
    }

    return true;
  } catch (err) {
    console.error("ensureDatabaseSeeded error:", err);
    return false;
  }
}
