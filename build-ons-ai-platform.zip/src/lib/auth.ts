import { cookies } from "next/headers";
import { db } from "@/db";
import { users, sessions } from "@/db/schema";
import { eq, and, gt } from "drizzle-orm";
import crypto from "crypto";

export const SESSION_COOKIE_NAME = "ons_session";

export interface CurrentUser {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar: string | null;
  plan: string | null;
  credits: number | null;
  status: string | null;
}

export async function createSession(userId: string, reqHeaders?: Headers): Promise<string> {
  const token = crypto.randomUUID();
  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days
  const ipAddress = reqHeaders?.get("x-forwarded-for") || reqHeaders?.get("x-real-ip") || "127.0.0.1";
  const userAgent = reqHeaders?.get("user-agent") || "unknown";

  await db.insert(sessions).values({
    id: crypto.randomUUID(),
    userId,
    token,
    expiresAt,
    ipAddress,
    userAgent,
  });

  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    expires: expiresAt,
  });

  return token;
}

export async function getSessionUser(): Promise<CurrentUser | null> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(SESSION_COOKIE_NAME)?.value;
    if (!token) return null;

    const [sessionRecord] = await db
      .select({
        session: sessions,
        user: users,
      })
      .from(sessions)
      .innerJoin(users, eq(sessions.userId, users.id))
      .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())))
      .limit(1);

    if (!sessionRecord || sessionRecord.user.status === "suspended") {
      return null;
    }

    return {
      id: sessionRecord.user.id,
      name: sessionRecord.user.name,
      email: sessionRecord.user.email,
      role: sessionRecord.user.role,
      avatar: sessionRecord.user.avatar,
      plan: sessionRecord.user.plan,
      credits: sessionRecord.user.credits,
      status: sessionRecord.user.status,
    };
  } catch (err) {
    console.error("getSessionUser error:", err);
    return null;
  }
}

export async function destroySession(): Promise<void> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(SESSION_COOKIE_NAME)?.value;
    if (token) {
      await db.delete(sessions).where(eq(sessions.token, token));
    }
    cookieStore.delete(SESSION_COOKIE_NAME);
  } catch (err) {
    console.error("destroySession error:", err);
  }
}
