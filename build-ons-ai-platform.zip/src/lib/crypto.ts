import crypto from "crypto";

const ENCRYPTION_KEY = process.env.ENCRYPTION_SECRET || "ons-ai-super-platform-secret-32b!"; // 32 chars
const ALGORITHM = "aes-256-gcm";

// Ensure 32-byte key
function getDerivedKey(): Buffer {
  return crypto.scryptSync(ENCRYPTION_KEY, "ons_salt_2026", 32);
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const derived = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, combinedHash: string): boolean {
  if (!combinedHash || !combinedHash.includes(":")) return false;
  const [salt, key] = combinedHash.split(":");
  const derived = crypto.scryptSync(password, salt, 64).toString("hex");
  return crypto.timingSafeEqual(Buffer.from(key, "hex"), Buffer.from(derived, "hex"));
}

export function encryptApiKey(text: string): string {
  if (!text) return "";
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(ALGORITHM, getDerivedKey(), iv);
  let encrypted = cipher.update(text, "utf8", "hex");
  encrypted += cipher.final("hex");
  const authTag = cipher.getAuthTag().toString("hex");
  return `${iv.toString("hex")}:${authTag}:${encrypted}`;
}

export function decryptApiKey(encryptedCombined: string): string {
  if (!encryptedCombined) return "";
  try {
    const [ivHex, authTagHex, encryptedText] = encryptedCombined.split(":");
    if (!ivHex || !authTagHex || !encryptedText) return encryptedCombined; // Return as-is if unencrypted
    const decipher = crypto.createDecipheriv(ALGORITHM, getDerivedKey(), Buffer.from(ivHex, "hex"));
    decipher.setAuthTag(Buffer.from(authTagHex, "hex"));
    let decrypted = decipher.update(encryptedText, "hex", "utf8");
    decrypted += decipher.final("utf8");
    return decrypted;
  } catch (err) {
    console.error("Error decrypting API key:", err);
    return "";
  }
}

export function maskApiKey(key: string): string {
  if (!key) return "Not configured";
  if (key.length <= 8) return "••••••••";
  return `${key.slice(0, 4)}••••••••${key.slice(-4)}`;
}
