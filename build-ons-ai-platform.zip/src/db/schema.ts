import { pgTable, text, varchar, integer, boolean, timestamp } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: varchar("id", { length: 128 }).primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").notNull().default("user"), // 'admin' | 'user' | 'collaborator'
  avatar: text("avatar"),
  plan: text("plan").default("Pro"),
  credits: integer("credits").default(10000),
  status: text("status").default("active"), // 'active' | 'suspended'
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const sessions = pgTable("sessions", {
  id: varchar("id", { length: 128 }).primaryKey(),
  userId: varchar("user_id", { length: 128 })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const aiProviders = pgTable("ai_providers", {
  id: varchar("id", { length: 128 }).primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  baseUrl: text("base_url").notNull(),
  apiKeyEncrypted: text("api_key_encrypted"),
  isEnabled: boolean("is_enabled").default(true).notNull(),
  isDefault: boolean("is_default").default(false).notNull(),
  description: text("description"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const aiModels = pgTable("ai_models", {
  id: varchar("id", { length: 128 }).primaryKey(),
  providerId: varchar("provider_id", { length: 128 })
    .notNull()
    .references(() => aiProviders.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  modelId: text("model_id").notNull(),
  contextWindow: integer("context_window").default(128000),
  supportsVision: boolean("supports_vision").default(false),
  supportsStreaming: boolean("supports_streaming").default(true),
  category: text("category").default("chat"), // 'chat' | 'reasoning' | 'code' | 'image' | 'voice'
  isEnabled: boolean("is_enabled").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const conversations = pgTable("conversations", {
  id: varchar("id", { length: 128 }).primaryKey(),
  userId: varchar("user_id", { length: 128 })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull().default("New Conversation"),
  modelId: text("model_id").notNull().default("gpt-4o"),
  providerId: text("provider_id").notNull().default("openai"),
  systemPrompt: text("system_prompt"),
  pinned: boolean("pinned").default(false).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const messages = pgTable("messages", {
  id: varchar("id", { length: 128 }).primaryKey(),
  conversationId: varchar("conversation_id", { length: 128 })
    .notNull()
    .references(() => conversations.id, { onDelete: "cascade" }),
  role: text("role").notNull(), // 'user' | 'assistant' | 'system'
  content: text("content").notNull(),
  attachments: text("attachments"), // JSON string
  tokens: integer("tokens").default(0),
  model: text("model"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const projects = pgTable("projects", {
  id: varchar("id", { length: 128 }).primaryKey(),
  userId: varchar("user_id", { length: 128 })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description"),
  toolType: text("tool_type").notNull(), // 'blog' | 'email' | 'article' | 'summarizer' | 'code' | 'website' | 'image' | 'video' | 'research' | 'doc' | 'voice'
  content: text("content").notNull(),
  metadata: text("metadata"), // JSON string
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const agents = pgTable("agents", {
  id: varchar("id", { length: 128 }).primaryKey(),
  userId: varchar("user_id", { length: 128 })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  avatar: text("avatar"),
  role: text("role").notNull(),
  description: text("description"),
  systemPrompt: text("system_prompt").notNull(),
  memory: text("memory"), // JSON string or text history
  tools: text("tools"), // JSON array of enabled tool keys
  isPublic: boolean("is_public").default(false).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const uploadedFiles = pgTable("uploaded_files", {
  id: varchar("id", { length: 128 }).primaryKey(),
  userId: varchar("user_id", { length: 128 })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  fileName: text("file_name").notNull(),
  fileType: text("file_type").notNull(),
  fileSize: integer("file_size").notNull(),
  url: text("url"),
  contentText: text("content_text"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const userSettings = pgTable("user_settings", {
  id: varchar("id", { length: 128 }).primaryKey(),
  userId: varchar("user_id", { length: 128 })
    .notNull()
    .unique()
    .references(() => users.id, { onDelete: "cascade" }),
  theme: text("theme").default("dark").notNull(),
  defaultModel: text("default_model").default("gpt-4o").notNull(),
  defaultProvider: text("default_provider").default("openai").notNull(),
  customApiKey: text("custom_api_key"),
  notifications: boolean("notifications").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const apiUsage = pgTable("api_usage", {
  id: varchar("id", { length: 128 }).primaryKey(),
  userId: varchar("user_id", { length: 128 }).references(() => users.id, { onDelete: "set null" }),
  providerId: text("provider_id").notNull(),
  modelId: text("model_id").notNull(),
  toolType: text("tool_type").notNull().default("chat"),
  tokensPrompt: integer("tokens_prompt").default(0),
  tokensCompletion: integer("tokens_completion").default(0),
  cost: text("cost").default("0.00"),
  status: text("status").default("success"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const errorLogs = pgTable("error_logs", {
  id: varchar("id", { length: 128 }).primaryKey(),
  source: text("source").notNull(),
  message: text("message").notNull(),
  stack: text("stack"),
  severity: text("severity").default("error"),
  resolved: boolean("resolved").default(false).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});
