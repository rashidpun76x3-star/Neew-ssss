"use client";

import React, { useState } from "react";
import { Check, Copy } from "lucide-react";

interface MarkdownRendererProps {
  content: string;
}

export function MarkdownRenderer({ content }: MarkdownRendererProps) {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const handleCopy = (code: string, index: number) => {
    navigator.clipboard.writeText(code);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  // Split content by code blocks ```lang ... ```
  const parts = content.split(/(```[\s\S]*?```)/g);

  return (
    <div className="space-y-3 leading-relaxed text-sm md:text-base break-words">
      {parts.map((part, idx) => {
        if (part.startsWith("```") && part.endsWith("```")) {
          // Code block
          const lines = part.slice(3, -3).trim().split("\n");
          const firstLine = lines[0].trim();
          const language = /^[a-zA-Z0-9_-]+$/.test(firstLine) ? firstLine : "";
          const code = (language ? lines.slice(1) : lines).join("\n");

          return (
            <div
              key={idx}
              className="my-3 rounded-xl overflow-hidden border border-slate-700/60 bg-slate-950/90 shadow-lg"
            >
              <div className="flex items-center justify-between px-4 py-2 bg-slate-900/80 border-b border-slate-800 text-xs text-slate-400 font-mono">
                <span>{language || "code"}</span>
                <button
                  onClick={() => handleCopy(code, idx)}
                  className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                  title="Copy code"
                >
                  {copiedIndex === idx ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
              <pre className="p-4 overflow-x-auto text-xs md:text-sm font-mono text-purple-200/90 leading-relaxed">
                <code>{code}</code>
              </pre>
            </div>
          );
        }

        // Render formatted text lines
        const paragraphs = part.split("\n\n");
        return (
          <React.Fragment key={idx}>
            {paragraphs.map((p, pIdx) => {
              const trimmed = p.trim();
              if (!trimmed) return null;

              // Headers
              if (trimmed.startsWith("### ")) {
                return (
                  <h3 key={pIdx} className="text-base md:text-lg font-bold text-purple-300 mt-4 mb-2 flex items-center gap-2">
                    {trimmed.replace(/^###\s+/, "")}
                  </h3>
                );
              }
              if (trimmed.startsWith("## ")) {
                return (
                  <h2 key={pIdx} className="text-lg md:text-xl font-bold text-white mt-5 mb-2 border-b border-slate-800/80 pb-1">
                    {trimmed.replace(/^##\s+/, "")}
                  </h2>
                );
              }
              if (trimmed.startsWith("# ")) {
                return (
                  <h1 key={pIdx} className="text-xl md:text-2xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-cyan-400 mt-6 mb-3">
                    {trimmed.replace(/^#\s+/, "")}
                  </h1>
                );
              }

              // Blockquotes
              if (trimmed.startsWith("> ")) {
                return (
                  <blockquote
                    key={pIdx}
                    className="border-l-4 border-purple-500 pl-4 py-1.5 my-2 bg-purple-950/20 rounded-r-lg italic text-slate-300 text-sm"
                  >
                    {trimmed.replace(/^>\s+/, "")}
                  </blockquote>
                );
              }

              // Unordered lists
              if (trimmed.split("\n").every((line) => line.trim().startsWith("- ") || line.trim().startsWith("* "))) {
                const listItems = trimmed.split("\n");
                return (
                  <ul key={pIdx} className="list-disc list-inside space-y-1 my-2 text-slate-300 pl-1">
                    {listItems.map((li, liIdx) => (
                      <li key={liIdx} className="text-sm md:text-base leading-relaxed">
                        <FormattedInline text={li.replace(/^[-*]\s+/, "")} />
                      </li>
                    ))}
                  </ul>
                );
              }

              // Ordered lists
              if (trimmed.split("\n").every((line) => /^\d+\.\s+/.test(line.trim()))) {
                const listItems = trimmed.split("\n");
                return (
                  <ol key={pIdx} className="list-decimal list-inside space-y-1 my-2 text-slate-300 pl-1">
                    {listItems.map((li, liIdx) => (
                      <li key={liIdx} className="text-sm md:text-base leading-relaxed">
                        <FormattedInline text={li.replace(/^\d+\.\s+/, "")} />
                      </li>
                    ))}
                  </ol>
                );
              }

              return (
                <p key={pIdx} className="text-slate-200/90 leading-relaxed text-sm md:text-base">
                  <FormattedInline text={trimmed} />
                </p>
              );
            })}
          </React.Fragment>
        );
      })}
    </div>
  );
}

function FormattedInline({ text }: { text: string }) {
  // Support bold **text** and inline code `code`
  const tokens = text.split(/(\*\*.*?\*\*|`.*?`)/g);

  return (
    <>
      {tokens.map((token, i) => {
        if (token.startsWith("**") && token.endsWith("**")) {
          return (
            <strong key={i} className="font-semibold text-white">
              {token.slice(2, -2)}
            </strong>
          );
        }
        if (token.startsWith("`") && token.endsWith("`")) {
          return (
            <code
              key={i}
              className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 font-mono text-xs text-purple-300"
            >
              {token.slice(1, -1)}
            </code>
          );
        }
        return <span key={i}>{token}</span>;
      })}
    </>
  );
}
