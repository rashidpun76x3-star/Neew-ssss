"use client";

import React from "react";
import {
  Sparkles,
  MessageSquare,
  Wrench,
  Bot,
  Shield,
  Zap,
  Code,
  Globe,
  FileText,
  Search,
  Mic,
  Video,
  Image,
  ArrowRight,
  Cpu,
  Layers,
  Lock,
} from "lucide-react";

interface OverviewViewProps {
  onViewChange: (view: string) => void;
  currentUser: any;
  onOpenAuth: () => void;
}

export function OverviewView({ onViewChange, currentUser, onOpenAuth }: OverviewViewProps) {
  const providerBadges = [
    { name: "OpenAI (GPT-4o)", color: "from-emerald-500/20 to-teal-500/10" },
    { name: "Anthropic Claude 3.5", color: "from-amber-500/20 to-orange-500/10" },
    { name: "Google Gemini 2.0", color: "from-blue-500/20 to-cyan-500/10" },
    { name: "DeepSeek R1/V3", color: "from-indigo-500/20 to-purple-500/10" },
    { name: "Groq LPU (Ultra Fast)", color: "from-rose-500/20 to-pink-500/10" },
    { name: "OpenRouter (200+ Models)", color: "from-purple-500/20 to-indigo-500/10" },
    { name: "Alibaba Qwen 2.5", color: "from-cyan-500/20 to-blue-500/10" },
    { name: "Zhipu GLM-4", color: "from-emerald-500/20 to-cyan-500/10" },
    { name: "MiniMax Multimodal", color: "from-violet-500/20 to-fuchsia-500/10" },
    { name: "Custom API Endpoint", color: "from-slate-500/20 to-slate-700/10" },
  ];

  const featureCards = [
    {
      title: "Multi-Model AI Chat Studio",
      description: "Seamlessly switch between GPT-4o, Claude 3.5 Sonnet, Gemini Pro, and DeepSeek R1 with streaming and file attachments.",
      icon: MessageSquare,
      view: "chat",
      gradient: "from-purple-600 to-indigo-600",
      pill: "10 Providers",
    },
    {
      title: "18+ Production AI Tools",
      description: "Writing, Visuals, Code Generation, Full Website Sandbox, Video Storyboards, and Voice synthesis.",
      icon: Wrench,
      view: "tools",
      gradient: "from-cyan-600 to-blue-600",
      pill: "Functional Suite",
    },
    {
      title: "Autonomous Agent Swarms",
      description: "Deploy self-directed AI agents with multi-step reasoning, internal tools, memory state, and custom missions.",
      icon: Bot,
      view: "agents",
      gradient: "from-fuchsia-600 to-pink-600",
      pill: "Multi-Agent",
    },
    {
      title: "Enterprise API Management",
      description: "Bring your own API keys, set base URLs, test live connections with zero client-side secret exposure.",
      icon: Shield,
      view: "admin",
      gradient: "from-amber-600 to-orange-600",
      pill: "AES-256-GCM",
    },
  ];

  const quickTools = [
    { name: "Website Generator", desc: "Build & preview live Tailwind web apps", icon: Globe, cat: "Development" },
    { name: "Code Debugger", desc: "Security audit, performance & memory fixes", icon: Code, cat: "Development" },
    { name: "PDF Chat & Reader", desc: "Deep document QA & data extraction", icon: FileText, cat: "Documents" },
    { name: "AI Research Assistant", desc: "Multi-source literature review & citations", icon: Search, cat: "Research" },
    { name: "Text to Speech & Audio", desc: "Natural voice narration & SSML scripts", icon: Mic, cat: "Voice" },
    { name: "Text to Video Director", desc: "Scene-by-scene cinematic prompts", icon: Video, cat: "Video" },
  ];

  return (
    <div className="space-y-8 animate-fadeIn pb-12">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-3xl glass-panel p-6 md:p-12 border border-slate-800 shadow-2xl">
        {/* Glow lights */}
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-cyan-600/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border border-purple-500/20 text-purple-300 text-xs font-semibold tracking-wide">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Complete AI Super Platform – Ready to Deploy</span>
          </div>

          <h1 className="text-3xl md:text-5xl font-black text-white tracking-tight leading-tight">
            Unified Autonomous Intelligence for{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-cyan-400 to-indigo-400 glow-text">
              Teams & Developers
            </span>
          </h1>

          <p className="text-sm md:text-base text-slate-300 leading-relaxed max-w-2xl">
            ONS AI brings together multi-provider foundation models (OpenAI, Claude, Gemini, DeepSeek, Groq, Qwen, GLM, MiniMax), 18+ high-throughput production tools, and autonomous AI agents into one sovereign cloud operating system.
          </p>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center gap-3 pt-3">
            <button
              onClick={() => onViewChange("chat")}
              className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-600 hover:opacity-95 text-white font-semibold text-sm shadow-xl shadow-purple-500/20 transition active:scale-95 cursor-pointer"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Launch AI Chat</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onViewChange("tools")}
              className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 text-slate-200 font-semibold text-sm transition cursor-pointer"
            >
              <Wrench className="w-4 h-4 text-cyan-400" />
              <span>Explore 18 AI Tools</span>
            </button>

            <button
              onClick={() => onViewChange("agents")}
              className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 text-slate-200 font-semibold text-sm transition cursor-pointer"
            >
              <Bot className="w-4 h-4 text-purple-400" />
              <span>Run AI Agent Swarm</span>
            </button>
          </div>
        </div>
      </div>

      {/* Provider Pill Ticker */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
            Integrated Foundation Model Providers
          </span>
          <span className="text-xs text-purple-400 font-mono">10 Active Engines</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
          {providerBadges.map((p, i) => (
            <div
              key={i}
              className={`p-2.5 rounded-xl bg-gradient-to-r ${p.color} border border-slate-800/80 text-center text-xs font-medium text-slate-200 truncate shadow-sm`}
            >
              {p.name}
            </div>
          ))}
        </div>
      </div>

      {/* Core Platform Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {featureCards.map((card, idx) => {
          const Icon = card.icon;
          return (
            <div
              key={idx}
              onClick={() => onViewChange(card.view)}
              className="group p-6 rounded-2xl glass-panel border border-slate-800 hover:border-purple-500/40 hover:bg-slate-800/50 transition cursor-pointer space-y-3 relative overflow-hidden shadow-lg"
            >
              <div className="flex items-center justify-between">
                <div
                  className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${card.gradient} flex items-center justify-center text-white shadow-md group-hover:scale-110 transition`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <span className="px-2 py-0.5 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-[10px] font-mono font-bold">
                  {card.pill}
                </span>
              </div>

              <h3 className="text-base font-bold text-white group-hover:text-purple-300 transition">
                {card.title}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">{card.description}</p>

              <div className="pt-2 flex items-center gap-1.5 text-xs text-purple-400 font-semibold group-hover:translate-x-1 transition">
                <span>Launch Studio</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Launchpad for Functional Tools */}
      <div className="rounded-3xl glass-panel p-6 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-cyan-400" />
              Instant Production Launchpad
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Jump straight into specialized generators, debuggers, and synthesizers.
            </p>
          </div>
          <button
            onClick={() => onViewChange("tools")}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
          >
            <span>View all 18 tools</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {quickTools.map((tool, idx) => {
            const Icon = tool.icon;
            return (
              <div
                key={idx}
                onClick={() => onViewChange("tools")}
                className="p-3.5 rounded-xl bg-slate-900/70 hover:bg-slate-800/80 border border-slate-800 hover:border-slate-700 transition cursor-pointer flex items-start gap-3 group"
              >
                <div className="p-2 rounded-lg bg-slate-800 group-hover:bg-purple-600/20 text-purple-400 transition">
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1 truncate">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-white group-hover:text-purple-300 transition">
                      {tool.name}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">{tool.cat}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5 truncate">{tool.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
