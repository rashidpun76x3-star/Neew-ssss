"use client";

import React, { useState } from "react";
import {
  Sparkles,
  Sun,
  Moon,
  Shield,
  User as UserIcon,
  LogOut,
  LogIn,
  Menu,
  ChevronDown,
  Layers,
  Cpu,
} from "lucide-react";

interface NavbarProps {
  currentUser: any;
  currentView: string;
  onViewChange: (view: string) => void;
  onOpenAuth: () => void;
  onLogout: () => void;
  onToggleSidebar: () => void;
  activeModel?: string;
}

export function Navbar({
  currentUser,
  currentView,
  onViewChange,
  onOpenAuth,
  onLogout,
  onToggleSidebar,
  activeModel = "GPT-4o",
}: NavbarProps) {
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const toggleTheme = () => {
    const nextTheme = theme === "dark" ? "light" : "dark";
    setTheme(nextTheme);
    if (typeof document !== "undefined") {
      document.documentElement.classList.toggle("dark", nextTheme === "dark");
      document.documentElement.classList.toggle("light", nextTheme === "light");
    }
  };

  const getViewTitle = () => {
    switch (currentView) {
      case "chat":
        return "AI Chat Studio";
      case "tools":
        return "AI Tools Suite";
      case "agents":
        return "Autonomous AI Agents";
      case "projects":
        return "Saved Projects";
      case "admin":
        return "Admin Governance Suite";
      case "settings":
        return "Platform Settings";
      default:
        return "Platform Overview";
    }
  };

  return (
    <header className="sticky top-0 z-30 h-16 w-full glass-panel border-b border-slate-800/80 px-4 md:px-6 flex items-center justify-between">
      {/* Left section: Hamburger & Logo & Title */}
      <div className="flex items-center gap-3 md:gap-4">
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/80 transition md:hidden"
          title="Toggle Navigation"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Brand */}
        <div
          onClick={() => onViewChange("overview")}
          className="flex items-center gap-2.5 cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 p-0.5 shadow-lg shadow-purple-500/20 group-hover:scale-105 transition">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-cyan-400 group-hover:rotate-12 transition" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-lg tracking-tight text-white glow-text">
                ONS <span className="text-cyan-400">AI</span>
              </span>
              <span className="px-1.5 py-0.2 rounded-md bg-purple-500/10 border border-purple-500/20 text-purple-400 text-[10px] font-mono font-bold">
                v2.4
              </span>
            </div>
          </div>
        </div>

        {/* Breadcrumb indicator (desktop) */}
        <div className="hidden lg:flex items-center gap-2 pl-4 border-l border-slate-800 text-xs text-slate-400">
          <Layers className="w-3.5 h-3.5 text-slate-500" />
          <span>ONS Platform</span>
          <span className="text-slate-600">/</span>
          <span className="text-purple-400 font-medium">{getViewTitle()}</span>
        </div>
      </div>

      {/* Right section: Model Badge, Theme Toggle, Auth / User Menu */}
      <div className="flex items-center gap-2.5 md:gap-3.5">
        {/* Active Model pill */}
        <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300">
          <Cpu className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-slate-400">Engine:</span>
          <span className="font-semibold text-white">{activeModel}</span>
        </div>

        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white transition"
          title={`Switch to ${theme === "dark" ? "Light" : "Dark"} mode`}
        >
          {theme === "dark" ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-purple-400" />}
        </button>

        {/* User state */}
        {currentUser ? (
          <div className="relative">
            <button
              onClick={() => setUserMenuOpen(!userMenuOpen)}
              className="flex items-center gap-2 p-1.5 md:px-3 md:py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-200 transition"
            >
              <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-purple-500 to-indigo-600 flex items-center justify-center font-bold text-xs text-white">
                {currentUser.name?.[0] || "U"}
              </div>
              <div className="hidden md:flex flex-col text-left">
                <span className="text-xs font-semibold text-white leading-tight">{currentUser.name}</span>
                <span className="text-[10px] text-purple-400 leading-tight flex items-center gap-1">
                  {currentUser.role === "admin" && <Shield className="w-2.5 h-2.5" />}
                  {currentUser.role === "admin" ? "Administrator" : "Pro Plan"}
                </span>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden md:block" />
            </button>

            {/* Dropdown Menu */}
            {userMenuOpen && (
              <div className="absolute right-0 mt-2 w-52 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl py-2 z-50 animate-fadeIn text-xs">
                <div className="px-3 py-2 border-b border-slate-800 text-slate-400">
                  <div className="font-semibold text-white text-sm">{currentUser.name}</div>
                  <div className="truncate text-slate-400">{currentUser.email}</div>
                  <div className="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-400 text-[10px] font-medium">
                    Credits: {currentUser.credits?.toLocaleString() || "10,000"}
                  </div>
                </div>

                {currentUser.role === "admin" && (
                  <button
                    onClick={() => {
                      onViewChange("admin");
                      setUserMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 text-purple-300 hover:bg-purple-950/40 flex items-center gap-2 transition"
                  >
                    <Shield className="w-4 h-4 text-purple-400" />
                    <span>Admin Dashboard</span>
                  </button>
                )}

                <button
                  onClick={() => {
                    onViewChange("projects");
                    setUserMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-slate-300 hover:bg-slate-800 flex items-center gap-2 transition"
                >
                  <Layers className="w-4 h-4 text-slate-400" />
                  <span>My Saved Projects</span>
                </button>

                <button
                  onClick={() => {
                    onViewChange("settings");
                    setUserMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-slate-300 hover:bg-slate-800 flex items-center gap-2 transition"
                >
                  <UserIcon className="w-4 h-4 text-slate-400" />
                  <span>Account & API Settings</span>
                </button>

                <div className="border-t border-slate-800 my-1" />

                <button
                  onClick={() => {
                    setUserMenuOpen(false);
                    onLogout();
                  }}
                  className="w-full text-left px-3 py-2 text-rose-400 hover:bg-rose-950/30 flex items-center gap-2 transition"
                >
                  <LogOut className="w-4 h-4 text-rose-400" />
                  <span>Sign Out</span>
                </button>
              </div>
            )}
          </div>
        ) : (
          <button
            onClick={onOpenAuth}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:opacity-90 text-white text-xs font-semibold shadow-lg shadow-purple-500/20 transition cursor-pointer"
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Sign In</span>
          </button>
        )}
      </div>
    </header>
  );
}
