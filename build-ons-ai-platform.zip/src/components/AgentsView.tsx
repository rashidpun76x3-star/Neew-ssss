"use client";

import React, { useState, useEffect } from "react";
import {
  Bot,
  Plus,
  Play,
  Sparkles,
  Wrench,
  Brain,
  Trash2,
  RefreshCw,
  Copy,
  Check,
  Zap,
  ArrowRight,
  Shield,
  Layers,
} from "lucide-react";
import { MarkdownRenderer } from "./MarkdownRenderer";

interface AgentsViewProps {
  currentUser: any;
}

export function AgentsView({ currentUser }: AgentsViewProps) {
  const [agents, setAgents] = useState<any[]>([]);
  const [loadingAgents, setLoadingAgents] = useState(false);
  const [activeAgent, setActiveAgent] = useState<any | null>(null);
  const [taskInput, setTaskInput] = useState("");
  const [running, setRunning] = useState(false);
  const [agentResult, setAgentResult] = useState<string | null>(null);
  const [createModalOpen, setCreateModalOpen] = useState(false);

  // New agent form
  const [newName, setNewName] = useState("");
  const [newAvatar, setNewAvatar] = useState("🤖");
  const [newRole, setNewRole] = useState("Autonomous Specialist");
  const [newDesc, setNewDesc] = useState("");
  const [newPrompt, setNewPrompt] = useState("");
  const [newTools, setNewTools] = useState<string[]>(["web_search", "code_generator"]);
  const [creating, setCreating] = useState(false);

  const availableTools = [
    { key: "web_search", label: "Real-Time Web Intelligence" },
    { key: "code_generator", label: "Production Code Generator" },
    { key: "code_debugger", label: "Security & Memory Debugger" },
    { key: "document_summarizer", label: "Document Synthesis" },
    { key: "fact_checker", label: "Fact Verification & Citations" },
  ];

  const fetchAgents = async () => {
    setLoadingAgents(true);
    try {
      const res = await fetch("/api/agents");
      const data = await res.json();
      if (data.agents) {
        setAgents(data.agents);
        if (!activeAgent && data.agents.length > 0) {
          setActiveAgent(data.agents[0]);
          setTaskInput("Perform deep competitive intelligence on enterprise agent architectures in 2026.");
        }
      }
    } catch (err) {
      console.error("Failed to fetch agents:", err);
    } finally {
      setLoadingAgents(false);
    }
  };

  useEffect(() => {
    fetchAgents();
  }, []);

  const handleRunAgent = async () => {
    if (!activeAgent || !taskInput.trim() || running) return;

    setRunning(true);
    setAgentResult(null);

    try {
      const res = await fetch(`/api/agents/${activeAgent.id}/run`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ task: taskInput.trim() }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to execute agent");
      setAgentResult(data.result);
    } catch (err: any) {
      setAgentResult(`⚠️ Agent execution encountered error: ${err.message}`);
    } finally {
      setRunning(false);
    }
  };

  const handleCreateAgent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newPrompt) return;

    setCreating(true);
    try {
      const res = await fetch("/api/agents", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newName,
          avatar: newAvatar,
          role: newRole,
          description: newDesc,
          systemPrompt: newPrompt,
          tools: newTools,
        }),
      });

      const data = await res.json();
      if (res.ok && data.agent) {
        setAgents((prev) => [data.agent, ...prev]);
        setActiveAgent(data.agent);
        setCreateModalOpen(false);
        setNewName("");
        setNewPrompt("");
      }
    } catch (err) {
      console.error("Create agent error:", err);
    } finally {
      setCreating(false);
    }
  };

  const handleDeleteAgent = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await fetch(`/api/agents?id=${id}`, { method: "DELETE" });
      setAgents((prev) => prev.filter((a) => a.id !== id));
      if (activeAgent?.id === id) {
        setActiveAgent(agents.find((a) => a.id !== id) || null);
      }
    } catch (err) {
      console.error("Delete agent error:", err);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl glass-panel border border-slate-800 shadow-xl">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-xs font-semibold mb-2">
            <Bot className="w-3.5 h-3.5" />
            Autonomous Agent Orchestration
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight">
            Specialized Multi-Agent Swarms
          </h2>
          <p className="text-xs md:text-sm text-slate-400 mt-1">
            Deploy autonomous agents with persistent memory, tool calling, and multi-step reasoning.
          </p>
        </div>

        <button
          onClick={() => setCreateModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:opacity-90 text-white text-xs font-semibold shadow-lg shadow-purple-500/20 transition cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Create Custom Agent</span>
        </button>
      </div>

      {/* Agents Library Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {agents.map((agent) => {
          const isSelected = activeAgent?.id === agent.id;
          let toolsList: string[] = [];
          try {
            toolsList = agent.tools ? JSON.parse(agent.tools) : [];
          } catch (e) {}

          return (
            <div
              key={agent.id}
              onClick={() => {
                setActiveAgent(agent);
                setAgentResult(null);
              }}
              className={`p-5 rounded-2xl glass-panel border transition cursor-pointer flex flex-col justify-between space-y-3 relative group ${
                isSelected
                  ? "border-purple-500/50 bg-purple-950/20 shadow-lg shadow-purple-500/10"
                  : "border-slate-800 hover:border-slate-700 hover:bg-slate-900/60"
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-xl">
                    {agent.avatar || "🤖"}
                  </div>
                  {isSelected ? (
                    <span className="px-2 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-[10px] font-mono font-bold">
                      Active
                    </span>
                  ) : (
                    !agent.isPublic && (
                      <button
                        onClick={(e) => handleDeleteAgent(agent.id, e)}
                        className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-rose-400 transition"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )
                  )}
                </div>

                <h3 className="font-bold text-sm text-white group-hover:text-purple-300 transition leading-snug">
                  {agent.name}
                </h3>
                <span className="text-[11px] text-purple-400 font-medium block mt-0.5">
                  {agent.role}
                </span>

                <p className="text-xs text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                  {agent.description || agent.systemPrompt}
                </p>
              </div>

              {/* Tools chips */}
              <div className="pt-2 border-t border-slate-800/80 flex flex-wrap gap-1">
                {toolsList.map((t, i) => (
                  <span
                    key={i}
                    className="px-1.5 py-0.5 rounded bg-slate-800 text-[10px] text-slate-300 font-mono"
                  >
                    {t.replace(/_/g, " ")}
                  </span>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Active Agent Mission Runner */}
      {activeAgent && (
        <div className="rounded-3xl glass-panel p-6 border border-slate-800 shadow-2xl space-y-5 animate-fadeIn">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-2xl">
                {activeAgent.avatar || "🤖"}
              </div>
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <span>{activeAgent.name}</span>
                  <span className="px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-400 text-xs font-normal">
                    {activeAgent.role}
                  </span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">{activeAgent.description}</p>
              </div>
            </div>
          </div>

          {/* Mission Prompt Input */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Delegate Agent Mission:
            </label>
            <div className="relative">
              <textarea
                rows={3}
                value={taskInput}
                onChange={(e) => setTaskInput(e.target.value)}
                placeholder="Give this agent a complex strategic mission or coding task..."
                className="w-full px-4 py-3 rounded-2xl bg-slate-950/80 border border-slate-800 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-purple-500 transition leading-relaxed"
              />
            </div>
          </div>

          <button
            onClick={handleRunAgent}
            disabled={running || !taskInput.trim()}
            className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-600 hover:opacity-90 active:scale-98 text-white text-xs font-semibold shadow-xl shadow-purple-500/25 transition cursor-pointer disabled:opacity-50"
          >
            {running ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Agent Reasoning & Invocations in Progress...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>Execute Agent Mission</span>
              </>
            )}
          </button>

          {/* Mission Output */}
          {agentResult && (
            <div className="p-5 md:p-6 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3 animate-fadeIn">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <span className="text-xs font-bold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Brain className="w-4 h-4 text-purple-400" />
                  Agent Execution Log & Resolution
                </span>
                <button
                  onClick={() => navigator.clipboard.writeText(agentResult)}
                  className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Deliverable</span>
                </button>
              </div>
              <div className="max-h-[550px] overflow-y-auto pr-1">
                <MarkdownRenderer content={agentResult} />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Create Custom Agent Modal */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 space-y-4">
            <h3 className="text-xl font-bold text-white">Create Custom Autonomous Agent</h3>
            <form onSubmit={handleCreateAgent} className="space-y-3 text-xs">
              <div className="grid grid-cols-4 gap-2">
                <div className="col-span-1">
                  <label className="block text-slate-300 mb-1">Avatar</label>
                  <input
                    type="text"
                    value={newAvatar}
                    onChange={(e) => setNewAvatar(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-center text-lg"
                  />
                </div>
                <div className="col-span-3">
                  <label className="block text-slate-300 mb-1">Agent Name</label>
                  <input
                    type="text"
                    required
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="e.g. Athena (Chief Strategy Officer)"
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Agent Role</label>
                <input
                  type="text"
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value)}
                  placeholder="e.g. Cloud Security Auditor"
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Short Description</label>
                <input
                  type="text"
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="What is this agent's specialty?"
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Core System Instructions</label>
                <textarea
                  rows={4}
                  required
                  value={newPrompt}
                  onChange={(e) => setNewPrompt(e.target.value)}
                  placeholder="Define the agent's persona, constraints, reasoning methodology, and output format..."
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1.5">Enabled Agent Tools</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  {availableTools.map((t) => {
                    const isChecked = newTools.includes(t.key);
                    return (
                      <label
                        key={t.key}
                        className={`flex items-center gap-2 p-2 rounded-xl border cursor-pointer ${
                          isChecked
                            ? "bg-purple-950/40 border-purple-500/40 text-purple-300"
                            : "bg-slate-950 border-slate-800 text-slate-400"
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {
                            if (isChecked) {
                              setNewTools((p) => p.filter((x) => x !== t.key));
                            } else {
                              setNewTools((p) => [...p, t.key]);
                            }
                          }}
                          className="rounded border-slate-700 text-purple-600"
                        />
                        <span className="text-[11px]">{t.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creating}
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold"
                >
                  {creating ? "Deploying..." : "Deploy Agent"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
