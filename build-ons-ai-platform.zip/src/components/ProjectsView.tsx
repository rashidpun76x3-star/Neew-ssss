"use client";

import React, { useState, useEffect } from "react";
import { FolderGit2, Search, Trash2, Eye, Copy, Check, Sparkles, X } from "lucide-react";
import { MarkdownRenderer } from "./MarkdownRenderer";

interface ProjectsViewProps {
  currentUser: any;
}

export function ProjectsView({ currentUser }: ProjectsViewProps) {
  const [projects, setProjects] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [selectedProject, setSelectedProject] = useState<any | null>(null);
  const [copied, setCopied] = useState(false);

  const fetchProjects = async () => {
    try {
      const res = await fetch("/api/projects");
      const data = await res.json();
      if (data.projects) setProjects(data.projects);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await fetch(`/api/projects?id=${id}`, { method: "DELETE" });
      setProjects((p) => p.filter((x) => x.id !== id));
      if (selectedProject?.id === id) setSelectedProject(null);
    } catch (e) {
      console.error(e);
    }
  };

  const filtered = projects.filter(
    (p) =>
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.toolType.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl glass-panel border border-slate-800 shadow-xl">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-xs font-semibold mb-2">
            <FolderGit2 className="w-3.5 h-3.5" />
            Saved Output Artifacts
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight">Saved Projects</h2>
          <p className="text-xs md:text-sm text-slate-400 mt-1">
            Browse and retrieve generated articles, code snippets, research briefs, and websites.
          </p>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search saved projects..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
          />
        </div>
      </div>

      {/* Grid */}
      {filtered.length === 0 ? (
        <div className="p-12 text-center rounded-3xl glass-panel border border-slate-800 space-y-2">
          <p className="text-slate-400 text-sm">No saved projects found.</p>
          <p className="text-slate-500 text-xs">
            Run any tool in the AI Tools Suite and click "Save to Projects" to store it here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((proj) => (
            <div
              key={proj.id}
              onClick={() => setSelectedProject(proj)}
              className="p-5 rounded-2xl glass-panel border border-slate-800 hover:border-purple-500/40 hover:bg-slate-900/60 transition cursor-pointer flex flex-col justify-between space-y-3 group"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-400 font-mono text-[10px] uppercase">
                    {proj.toolType}
                  </span>
                  <button
                    onClick={(e) => handleDelete(proj.id, e)}
                    className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-rose-400 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <h3 className="font-bold text-sm text-white group-hover:text-purple-300 transition leading-snug">
                  {proj.title}
                </h3>
                <p className="text-xs text-slate-400 mt-2 line-clamp-3 leading-relaxed">
                  {proj.content.slice(0, 180)}...
                </p>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
                <span>{new Date(proj.createdAt).toLocaleDateString()}</span>
                <span className="text-purple-400 flex items-center gap-1">
                  <Eye className="w-3 h-3" /> View
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Project Detail Modal */}
      {selectedProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-2xl max-h-[85vh] flex flex-col rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 overflow-hidden">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <span className="text-[10px] font-mono text-purple-400 uppercase">
                  {selectedProject.toolType}
                </span>
                <h3 className="text-base font-bold text-white">{selectedProject.title}</h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(selectedProject.content);
                    setCopied(true);
                    setTimeout(() => setCopied(false), 2000);
                  }}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 text-xs"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? "Copied" : "Copy"}</span>
                </button>
                <button
                  onClick={() => setSelectedProject(null)}
                  className="p-1 text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto py-4">
              <MarkdownRenderer content={selectedProject.content} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
