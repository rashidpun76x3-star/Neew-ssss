"use client";

import React, { useState } from "react";
import {
  PenTool,
  Image as ImageIcon,
  Video,
  Mic,
  Code,
  FileText,
  Search,
  Sparkles,
  Play,
  Copy,
  Check,
  BookmarkPlus,
  Eye,
  RefreshCw,
  Volume2,
  VolumeX,
  Send,
  Layers,
  Terminal,
} from "lucide-react";
import { MarkdownRenderer } from "./MarkdownRenderer";

interface ToolsViewProps {
  currentUser: any;
  onProjectSaved?: () => void;
}

export function ToolsView({ currentUser, onProjectSaved }: ToolsViewProps) {
  const [activeCategory, setActiveCategory] = useState("writing");
  const [activeTool, setActiveTool] = useState("blog_generator");
  const [inputs, setInputs] = useState<Record<string, any>>({
    topic: "Autonomous AI Agents in Enterprise Cloud",
    audience: "CTOs and Software Architects",
    tone: "Authoritative & Forward-Looking",
    length: "1,200 words",
  });
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);
  const [previewTab, setPreviewTab] = useState<"code" | "preview">("preview");
  const [isSpeaking, setIsSpeaking] = useState(false);

  const categories = [
    { id: "writing", label: "AI Writing", icon: PenTool, count: 4 },
    { id: "image", label: "AI Image", icon: ImageIcon, count: 3 },
    { id: "video", label: "AI Video", icon: Video, count: 2 },
    { id: "voice", label: "AI Voice", icon: Mic, count: 3 },
    { id: "dev", label: "AI Development", icon: Code, count: 3 },
    { id: "doc", label: "AI Documents", icon: FileText, count: 3 },
    { id: "research", label: "AI Research", icon: Search, count: 3 },
  ];

  const toolsMap: Record<string, Array<{ id: string; label: string; desc: string }>> = {
    writing: [
      { id: "blog_generator", label: "Blog Generator", desc: "Long-form SEO authority blog posts" },
      { id: "email_writer", label: "Email Writer", desc: "High-conversion executive & sales pitches" },
      { id: "article_writer", label: "Article Writer", desc: "In-depth analytical feature articles" },
      { id: "text_summarizer", label: "Text Summarizer", desc: "Executive briefs & key bullet takeaways" },
    ],
    image: [
      { id: "text_to_image", label: "Text to Image", desc: "Photorealistic prompts & visual composition" },
      { id: "image_editing", label: "Image Editing", desc: "Generative inpainting & style transformation" },
      { id: "image_understanding", label: "Image Understanding", desc: "Computer vision analysis & UX review" },
    ],
    video: [
      { id: "text_to_video", label: "Text to Video", desc: "Scene-by-scene script & cinematic prompts" },
      { id: "image_to_video", label: "Image to Video", desc: "Camera motion vectors & lighting dynamics" },
    ],
    voice: [
      { id: "text_to_speech", label: "Text to Speech", desc: "Acoustic synthesis & natural voiceover" },
      { id: "speech_to_text", label: "Speech to Text", desc: "Audio intelligence & meeting transcription" },
      { id: "voice_assistant", label: "Voice Assistant", desc: "Conversational spoken voice copilot" },
    ],
    dev: [
      { id: "code_generator", label: "Code Generator", desc: "Production-grade type-safe implementations" },
      { id: "code_debugger", label: "Code Debugger", desc: "Security audit, memory leaks & optimizations" },
      { id: "website_generator", label: "Website Generator", desc: "Instant Tailwind HTML page with live sandbox preview" },
    ],
    doc: [
      { id: "pdf_reader", label: "PDF Reader", desc: "Semantic structural parsing & key statistics" },
      { id: "pdf_chat", label: "PDF Chat", desc: "Ask questions with exact citation extraction" },
      { id: "document_summarizer", label: "Document Summarizer", desc: "Legal & technical document synthesis" },
    ],
    research: [
      { id: "web_search", label: "Web Search", desc: "Deep multi-source web intelligence & facts" },
      { id: "research_assistant", label: "AI Research Assistant", desc: "Academic literature review & methodology" },
      { id: "translator", label: "Translator", desc: "Polyglot cultural adaptation & tonal fidelity" },
    ],
  };

  const handleToolSelect = (toolId: string) => {
    setActiveTool(toolId);
    setResult(null);
    setError(null);
    setSaved(false);

    // Initialize default inputs for tool
    switch (toolId) {
      case "blog_generator":
        setInputs({
          topic: "Autonomous AI Agents in Enterprise Cloud",
          audience: "CTOs and Software Architects",
          tone: "Authoritative & Forward-Looking",
          length: "1,200 words",
        });
        break;
      case "email_writer":
        setInputs({
          purpose: "Enterprise SaaS Partnership Briefing",
          recipient: "VP of Engineering",
          tone: "Crisp, Professional & High-ROI",
          keyPoints: "10x throughput, multi-model LLM routing, enterprise security",
        });
        break;
      case "article_writer":
        setInputs({
          title: "The Sovereign Cloud: Why Autonomous Compute is Eating Traditional SaaS",
        });
        break;
      case "text_summarizer":
        setInputs({
          text: "ONS AI represents a unified AI Super Platform featuring multi-provider model routing, 18 creative tools, autonomous agents, and enterprise AES-256 key encryption. The architecture is engineered on Next.js 15, Drizzle ORM, and PostgreSQL.",
          format: "Executive Summary & Actionable Recommendations",
        });
        break;
      case "text_to_image":
        setInputs({
          prompt: "Futuristic quantum computing laboratory suspended in a crystalline nebula, neon bioluminescent circuits, volumetric lighting",
          style: "Photorealistic 8K Unreal Engine 5 Cinematic",
          aspectRatio: "16:9",
        });
        break;
      case "image_editing":
        setInputs({
          description: "Urban architecture skyline photograph at noon",
          modifications: "Transform to cyberpunk dusk with holographic billboards and wet asphalt reflections",
        });
        break;
      case "image_understanding":
        setInputs({
          imageContext: "Screenshot of modern AI Cloud Analytics dashboard with token charts and provider latency metrics",
        });
        break;
      case "text_to_video":
        setInputs({
          prompt: "Drone fly-through of an orbital sovereign AI data center overlooking Earth at twilight",
          style: "IMAX Sci-Fi 60fps",
          duration: "15 seconds",
        });
        break;
      case "image_to_video":
        setInputs({
          sourceImage: "A high-altitude alpine glacier surrounded by aurora borealis",
          motion: "Slow dolly forward with shimmering auroral rays and gentle blowing snow",
        });
        break;
      case "text_to_speech":
        setInputs({
          text: "Welcome to ONS AI. All systems are operational. Multi-model routing is ready for your command.",
          voicePersona: "Executive Narrator (Deep & Resonant)",
        });
        break;
      case "speech_to_text":
        setInputs({
          audioContext: "Strategy session discussing Q3 budget allocation for GPU clusters and custom fine-tuning",
        });
        break;
      case "voice_assistant":
        setInputs({
          voiceQuery: "How does ONS AI encrypt API credentials and prevent client-side secret exposure?",
        });
        break;
      case "code_generator":
        setInputs({
          description: "A resilient Redis token bucket rate limiter in TypeScript for Next.js API route handlers",
          language: "TypeScript / Next.js",
          constraints: "Zero external dependencies, exponential backoff headers",
        });
        break;
      case "code_debugger":
        setInputs({
          code: `function handleData(req) {\n  let cache = {};\n  // Memory leak: cache grows unboundedly\n  return function(id) {\n    if (!cache[id]) cache[id] = fetch('/api/' + id);\n    return cache[id];\n  }\n}`,
        });
        break;
      case "website_generator":
        setInputs({
          prompt: "Next-gen AI Cyber Defense Operations Center with dark glowing glass cards, live threat status pill, and interactive incident table",
        });
        break;
      case "pdf_reader":
      case "pdf_chat":
        setInputs({
          documentText: "Q4 Enterprise Security Audit: Pass rate 99.4%, zero critical vulnerabilities detected, average incident response time decreased from 14 minutes to 82 seconds.",
          query: "What were the key security audit metrics and SLA improvements?",
        });
        break;
      case "document_summarizer":
        setInputs({
          documentText: "Sovereign AI Infrastructure Protocol: Outlines high-availability node clustering, failover latency under 5ms, and cryptographic key segregation.",
          format: "Structured Risk Matrix and Operational Action Items",
        });
        break;
      case "web_search":
      case "research_assistant":
        setInputs({
          query: "DeepSeek-R1 vs OpenAI o1 reasoning performance benchmarks in software engineering and competitive programming",
        });
        break;
      case "translator":
        setInputs({
          text: "Accelerating global innovation through sovereign autonomous intelligence.",
          targetLanguage: "Japanese (Business Formal Keigo)",
          tone: "Executive and Inspiring",
        });
        break;
      default:
        setInputs({});
    }
  };

  const handleExecuteTool = async () => {
    setLoading(true);
    setError(null);
    setResult(null);
    setSaved(false);

    try {
      const res = await fetch("/api/tools/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          toolKey: activeTool,
          inputs,
          providerSlug: "openai",
          modelId: "gpt-4o",
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Tool execution failed");

      setResult(data.result);
    } catch (err: any) {
      setError(err.message || "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  const handleSaveToProjects = async () => {
    if (!result) return;
    try {
      const toolObj = toolsMap[activeCategory]?.find((t) => t.id === activeTool);
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: `${toolObj?.label || "Tool"} - ${new Date().toLocaleDateString()}`,
          description: `Generated with ONS AI ${activeTool}`,
          toolType: activeTool,
          content: result,
        }),
      });

      if (res.ok) {
        setSaved(true);
        onProjectSaved?.();
      }
    } catch (err) {
      console.error("Save error:", err);
    }
  };

  const handleCopyResult = () => {
    if (!result) return;
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSpeak = () => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const textToSpeak = inputs.text || result?.slice(0, 300) || "ONS AI speech synthesis ready.";
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.rate = 1.0;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  // Extract clean HTML if website generator
  const extractHTML = (content: string) => {
    const match = content.match(/```html\s*([\s\S]*?)\s*```/);
    if (match && match[1]) return match[1];
    if (content.includes("<!DOCTYPE html>") || content.includes("<html")) return content;
    return null;
  };

  const currentToolList = toolsMap[activeCategory] || [];
  const activeToolObj = currentToolList.find((t) => t.id === activeTool) || currentToolList[0];
  const generatedHtml = result ? extractHTML(result) : null;

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const isActive = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => {
                setActiveCategory(cat.id);
                const firstTool = toolsMap[cat.id]?.[0]?.id || "blog_generator";
                handleToolSelect(firstTool);
              }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                isActive
                  ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-500/20"
                  : "bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{cat.label}</span>
              <span
                className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                  isActive ? "bg-white/20 text-white" : "bg-slate-800 text-slate-400"
                }`}
              >
                {cat.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Main Workspace Layout: Tool selector on left, input and output on right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Sub-Tool List */}
        <div className="lg:col-span-4 space-y-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 block px-1">
            Available {categories.find((c) => c.id === activeCategory)?.label} Tools
          </span>
          <div className="space-y-2">
            {currentToolList.map((tool) => {
              const isSelected = activeTool === tool.id;
              return (
                <div
                  key={tool.id}
                  onClick={() => handleToolSelect(tool.id)}
                  className={`p-3.5 rounded-2xl border transition cursor-pointer ${
                    isSelected
                      ? "bg-purple-600/15 border-purple-500/40 text-white shadow-md"
                      : "bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-xs text-white">{tool.label}</span>
                    {isSelected && (
                      <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 leading-snug">{tool.desc}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Interactive Configuration and Output */}
        <div className="lg:col-span-8 space-y-6">
          {/* Tool Card */}
          <div className="rounded-3xl glass-panel p-5 md:p-6 border border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  {activeToolObj?.label}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">{activeToolObj?.desc}</p>
              </div>

              {activeTool === "text_to_speech" && (
                <button
                  onClick={handleSpeak}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/30 text-cyan-300 text-xs font-medium transition cursor-pointer"
                >
                  {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                  <span>{isSpeaking ? "Stop Voice" : "Test Spoken Audio"}</span>
                </button>
              )}
            </div>

            {/* Dynamic Inputs Form */}
            <div className="space-y-3">
              {Object.keys(inputs).map((key) => {
                const val = inputs[key];
                const isLongText = key === "text" || key === "documentText" || key === "code";
                return (
                  <div key={key}>
                    <label className="block text-xs font-semibold text-slate-300 capitalize mb-1">
                      {key.replace(/([A-Z])/g, " $1")}
                    </label>
                    {isLongText ? (
                      <textarea
                        rows={key === "code" ? 5 : 4}
                        value={val || ""}
                        onChange={(e) => setInputs((p) => ({ ...p, [key]: e.target.value }))}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 transition leading-relaxed resize-y"
                      />
                    ) : (
                      <input
                        type="text"
                        value={val || ""}
                        onChange={(e) => setInputs((p) => ({ ...p, [key]: e.target.value }))}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 transition"
                      />
                    )}
                  </div>
                );
              })}
            </div>

            {/* Execute Button */}
            <div className="pt-2 flex items-center justify-between">
              <button
                onClick={handleExecuteTool}
                disabled={loading}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-600 hover:opacity-90 active:scale-98 text-white text-xs font-semibold shadow-lg shadow-purple-500/20 transition cursor-pointer disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Executing with ONS AI Engine...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Run {activeToolObj?.label}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Error Banner */}
          {error && (
            <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs">
              {error}
            </div>
          )}

          {/* Result Card */}
          {result && (
            <div className="rounded-3xl glass-panel p-5 md:p-6 border border-slate-800 shadow-2xl space-y-4 animate-fadeIn">
              {/* Output Actions Bar */}
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    Generated Output
                  </span>
                  {activeTool === "website_generator" && generatedHtml && (
                    <div className="flex items-center gap-1 p-0.5 rounded-lg bg-slate-800 text-[11px]">
                      <button
                        onClick={() => setPreviewTab("preview")}
                        className={`px-2 py-0.5 rounded-md font-medium transition ${
                          previewTab === "preview" ? "bg-purple-600 text-white" : "text-slate-400"
                        }`}
                      >
                        <Eye className="w-3 h-3 inline mr-1" />
                        Live Preview
                      </button>
                      <button
                        onClick={() => setPreviewTab("code")}
                        className={`px-2 py-0.5 rounded-md font-medium transition ${
                          previewTab === "code" ? "bg-purple-600 text-white" : "text-slate-400"
                        }`}
                      >
                        <Terminal className="w-3 h-3 inline mr-1" />
                        HTML Code
                      </button>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyResult}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition cursor-pointer"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleSaveToProjects}
                    className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                      saved
                        ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                        : "bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30"
                    }`}
                  >
                    <BookmarkPlus className="w-3 h-3" />
                    <span>{saved ? "Saved in Projects" : "Save to Projects"}</span>
                  </button>
                </div>
              </div>

              {/* Live Preview Mode for Website Generator */}
              {activeTool === "website_generator" && generatedHtml && previewTab === "preview" ? (
                <div className="rounded-2xl border border-slate-800 overflow-hidden bg-slate-950">
                  <div className="h-8 bg-slate-900 border-b border-slate-800 flex items-center px-3 gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                    <span className="text-[11px] font-mono text-slate-400 ml-2">
                      https://sandbox.ons.ai/preview
                    </span>
                  </div>
                  <iframe
                    srcDoc={generatedHtml}
                    title="Website Generator Live Sandbox"
                    className="w-full h-96 border-0 bg-white"
                    sandbox="allow-scripts"
                  />
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 max-h-[500px] overflow-y-auto">
                  <MarkdownRenderer content={result} />
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
