"use client";

import React from "react";
import {
  LayoutDashboard,
  MessageSquare,
  Wrench,
  Bot,
  FolderGit2,
  Shield,
  Settings,
  Plus,
  Trash2,
  Pin,
  Sparkles,
  ChevronRight,
  ExternalLink,
} from "lucide-react";

interface SidebarProps {
  currentView: string;
  onViewChange: (view: string) => void;
  isOpen: boolean;
  onClose: () => void;
  conversations: any[];
  activeConversationId: string | null;
  onSelectConversation: (id: string) => void;
  onNewConversation: () => void;
  onDeleteConversation: (id: string) => void;
  currentUser: any;
}

export function Sidebar({
  currentView,
  onViewChange,
  isOpen,
  onClose,
  conversations,
  activeConversationId,
  onSelectConversation,
  onNewConversation,
  onDeleteConversation,
  currentUser,
}: SidebarProps) {
  const navItems = [
    { id: "overview", label: "Dashboard", icon: LayoutDashboard },
    { id: "chat", label: "AI Chat Studio", icon: MessageSquare, badge: "10 Providers" },
    { id: "tools", label: "AI Tools Suite", icon: Wrench, badge: "18 Tools" },
    { id: "agents", label: "Autonomous Agents", icon: Bot, badge: "Multi-Agent" },
    { id: "projects", label: "Saved Projects", icon: FolderGit2 },
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm md:hidden"
        />
      )}

      <aside
        className={`fixed md:sticky top-16 left-0 z-40 h-[calc(100vh-4rem)] w-64 md:w-64 glass-panel border-r border-slate-800/80 flex flex-col justify-between transition-transform duration-300 ease-in-out ${
          isOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        }`}
      >
        {/* Top: Primary Navigation */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
          {/* Main items */}
          <div className="space-y-1">
            <span className="px-3 text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
              Core Platform
            </span>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onViewChange(item.id);
                    onClose();
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition cursor-pointer ${
                    isActive
                      ? "bg-purple-600/15 border border-purple-500/30 text-purple-300 shadow-sm"
                      : "text-slate-400 hover:text-white hover:bg-slate-800/60"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? "text-purple-400" : "text-slate-400"}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className="px-1.5 py-0.5 rounded-md bg-purple-500/10 text-purple-400 text-[10px] font-mono">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Quick Chat Threads (when chat is active or relevant) */}
          <div className="space-y-1.5 pt-2 border-t border-slate-800/60">
            <div className="flex items-center justify-between px-3">
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                Recent Chats
              </span>
              <button
                onClick={() => {
                  onViewChange("chat");
                  onNewConversation();
                }}
                className="p-1 rounded-md text-purple-400 hover:text-purple-300 hover:bg-purple-500/10 transition"
                title="New Chat"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-1 max-h-48 overflow-y-auto pr-1">
              {conversations.length === 0 ? (
                <div className="px-3 py-2 text-[11px] text-slate-500 italic">No chat history yet</div>
              ) : (
                conversations.map((conv) => {
                  const isCurrent = activeConversationId === conv.id;
                  return (
                    <div
                      key={conv.id}
                      className={`group flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs cursor-pointer transition ${
                        isCurrent
                          ? "bg-slate-800/90 text-white font-medium border border-slate-700/60"
                          : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/60"
                      }`}
                      onClick={() => {
                        onViewChange("chat");
                        onSelectConversation(conv.id);
                        onClose();
                      }}
                    >
                      <div className="flex items-center gap-2 truncate pr-1">
                        <MessageSquare className="w-3 h-3 shrink-0 text-slate-500" />
                        <span className="truncate">{conv.title || "New Chat"}</span>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteConversation(conv.id);
                        }}
                        className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-rose-400 rounded transition"
                        title="Delete Chat"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Admin Section (Available or highlighted for admins) */}
          <div className="space-y-1 pt-2 border-t border-slate-800/60">
            <span className="px-3 text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
              Administration
            </span>
            <button
              onClick={() => {
                onViewChange("admin");
                onClose();
              }}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition cursor-pointer ${
                currentView === "admin"
                  ? "bg-purple-600/15 border border-purple-500/30 text-purple-300 shadow-sm"
                  : "text-slate-400 hover:text-white hover:bg-slate-800/60"
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Shield className="w-4 h-4 text-purple-400" />
                <span>Admin Governance</span>
              </div>
              <span className="px-1.5 py-0.5 rounded-md bg-purple-500/10 text-purple-400 text-[10px] font-mono">
                API Mgr
              </span>
            </button>
          </div>
        </div>

        {/* Bottom: Settings & System Status */}
        <div className="p-3 border-t border-slate-800/80 space-y-2">
          <button
            onClick={() => {
              onViewChange("settings");
              onClose();
            }}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition cursor-pointer ${
              currentView === "settings"
                ? "bg-slate-800 text-white"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <Settings className="w-4 h-4 text-slate-400" />
            <span>Platform Settings</span>
          </button>

          {/* Antideploy Ready Badge */}
          <div className="p-2.5 rounded-xl bg-gradient-to-r from-purple-950/40 to-cyan-950/40 border border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-semibold text-slate-300">Antideploy Ready</span>
            </div>
            <span className="text-[10px] text-cyan-400 font-mono">v2.4.0</span>
          </div>
        </div>
      </aside>
    </>
  );
}
