"use client";

import React, { useState, useEffect } from "react";
import { Settings, User, Key, Cpu, Shield, CheckCircle2, Lock } from "lucide-react";

interface SettingsViewProps {
  currentUser: any;
  onProfileUpdated?: () => void;
}

export function SettingsView({ currentUser, onProfileUpdated }: SettingsViewProps) {
  const [name, setName] = useState(currentUser?.name || "");
  const [defaultModel, setDefaultModel] = useState("gpt-4o");
  const [customKey, setCustomKey] = useState("");
  const [theme, setTheme] = useState("dark");
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await fetch("/api/auth/me");
        const data = await res.json();
        if (data.settings) {
          setDefaultModel(data.settings.defaultModel || "gpt-4o");
          setCustomKey(data.settings.customApiKey || "");
          setTheme(data.settings.theme || "dark");
        }
        if (data.user) {
          setName(data.user.name || "");
        }
      } catch (e) {
        console.error(e);
      }
    };
    fetchProfile();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSuccess(false);

    try {
      const res = await fetch("/api/auth/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          defaultModel,
          customApiKey: customKey,
          theme,
        }),
      });

      if (res.ok) {
        setSuccess(true);
        onProfileUpdated?.();
        setTimeout(() => setSuccess(false), 3000);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-fadeIn pb-12">
      <div className="p-6 rounded-3xl glass-panel border border-slate-800 shadow-xl">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-xs font-semibold mb-2">
          <Settings className="w-3.5 h-3.5" />
          User & Engine Preferences
        </div>
        <h2 className="text-2xl font-black text-white tracking-tight">Platform Settings</h2>
        <p className="text-xs md:text-sm text-slate-400 mt-1">
          Configure your user identity, default AI model engine, and private custom API credentials.
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-4">
        {/* Profile Card */}
        <div className="p-6 rounded-3xl glass-panel border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
            <User className="w-4 h-4 text-purple-400" />
            Account Information
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-300 mb-1 font-medium">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white"
              />
            </div>
            <div>
              <label className="block text-slate-300 mb-1 font-medium">Email Address</label>
              <input
                type="email"
                disabled
                value={currentUser?.email || "user@ons.ai"}
                className="w-full p-2.5 rounded-xl bg-slate-950/40 border border-slate-800/60 text-slate-500 cursor-not-allowed font-mono"
              />
            </div>
            <div className="flex gap-4 pt-1 text-slate-400">
              <span>
                Plan: <strong className="text-white">{currentUser?.plan || "Pro"}</strong>
              </span>
              <span>
                Role: <strong className="text-purple-400">{currentUser?.role || "User"}</strong>
              </span>
              <span>
                Credits: <strong className="text-cyan-400">{currentUser?.credits?.toLocaleString() || "10,000"}</strong>
              </span>
            </div>
          </div>
        </div>

        {/* AI Engine Defaults */}
        <div className="p-6 rounded-3xl glass-panel border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
            <Cpu className="w-4 h-4 text-cyan-400" />
            Default Model Routing
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-300 mb-1 font-medium">Default Chat & Tool Model</label>
              <select
                value={defaultModel}
                onChange={(e) => setDefaultModel(e.target.value)}
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white"
              >
                <option value="gpt-4o">OpenAI GPT-4o (Omni)</option>
                <option value="claude-3-5-sonnet-20241022">Anthropic Claude 3.5 Sonnet</option>
                <option value="gemini-1.5-pro">Google Gemini 1.5 Pro</option>
                <option value="deepseek-chat">DeepSeek Chat (V3)</option>
                <option value="deepseek-reasoner">DeepSeek Reasoner (R1)</option>
                <option value="llama-3.3-70b-versatile">Groq Llama 3.3 70B</option>
                <option value="qwen-2.5-72b-instruct">Alibaba Qwen 2.5 72B</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 mb-1 font-medium flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-purple-400" />
                Personal Bring-Your-Own API Key (BYOK Optional)
              </label>
              <input
                type="password"
                value={customKey}
                onChange={(e) => setCustomKey(e.target.value)}
                placeholder="sk-... (Overrides system default for your requests)"
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-xs"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">
                Leave blank to automatically use system-configured keys from the Admin API Manager.
              </span>
            </div>
          </div>
        </div>

        {/* Submit */}
        <div className="flex items-center justify-between pt-2">
          {success ? (
            <div className="text-xs text-emerald-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" />
              <span>Settings saved successfully!</span>
            </div>
          ) : <div />}

          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:opacity-90 text-white text-xs font-semibold shadow-lg shadow-purple-500/20 transition cursor-pointer"
          >
            {saving ? "Saving Changes..." : "Save Settings"}
          </button>
        </div>
      </form>
    </div>
  );
}
