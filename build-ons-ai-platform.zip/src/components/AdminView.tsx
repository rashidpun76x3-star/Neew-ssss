"use client";

import React, { useState, useEffect } from "react";
import {
  Shield,
  Key,
  Users,
  Cpu,
  BarChart3,
  AlertTriangle,
  UserCheck,
  Plus,
  RefreshCw,
  CheckCircle2,
  XCircle,
  Eye,
  Lock,
  Layers,
  Activity,
  Trash2,
} from "lucide-react";

interface AdminViewProps {
  currentUser: any;
}

export function AdminView({ currentUser }: AdminViewProps) {
  const [activeTab, setActiveTab] = useState<"keys" | "users" | "providers" | "models" | "analytics" | "logs" | "collaborators">("keys");

  // State for data
  const [keysList, setKeysList] = useState<any[]>([]);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [providersList, setProvidersList] = useState<any[]>([]);
  const [modelsList, setModelsList] = useState<any[]>([]);
  const [analytics, setAnalytics] = useState<any | null>(null);
  const [collabsList, setCollabsList] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [testStatus, setTestStatus] = useState<Record<string, { status: string; message: string }>>({});

  // Modals
  const [keyModalOpen, setKeyModalOpen] = useState(false);
  const [activeKeyProvider, setActiveKeyProvider] = useState<any | null>(null);
  const [inputKey, setInputKey] = useState("");
  const [savingKey, setSavingKey] = useState(false);

  const [providerModalOpen, setProviderModalOpen] = useState(false);
  const [newProvName, setNewProvName] = useState("");
  const [newProvSlug, setNewProvSlug] = useState("");
  const [newProvUrl, setNewProvUrl] = useState("");
  const [newProvModelId, setNewProvModelId] = useState("");
  const [savingProvider, setSavingProvider] = useState(false);

  const [collabModalOpen, setCollabModalOpen] = useState(false);
  const [newCollabName, setNewCollabName] = useState("");
  const [newCollabEmail, setNewCollabEmail] = useState("");
  const [newCollabRole, setNewCollabRole] = useState("collaborator");

  const fetchKeys = async () => {
    try {
      const res = await fetch("/api/admin/keys");
      const data = await res.json();
      if (data.keys) setKeysList(data.keys);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchUsers = async () => {
    try {
      const res = await fetch("/api/admin/users");
      const data = await res.json();
      if (data.users) setUsersList(data.users);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchProviders = async () => {
    try {
      const res = await fetch("/api/admin/providers");
      const data = await res.json();
      if (data.providers) setProvidersList(data.providers);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchModels = async () => {
    try {
      const res = await fetch("/api/admin/models");
      const data = await res.json();
      if (data.models) setModelsList(data.models);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchAnalytics = async () => {
    try {
      const res = await fetch("/api/admin/analytics");
      const data = await res.json();
      setAnalytics(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchCollaborators = async () => {
    try {
      const res = await fetch("/api/admin/collaborators");
      const data = await res.json();
      if (data.collaborators) setCollabsList(data.collaborators);
    } catch (e) {
      console.error(e);
    }
  };

  const refreshActiveTab = () => {
    setLoading(true);
    if (activeTab === "keys") fetchKeys();
    else if (activeTab === "users") fetchUsers();
    else if (activeTab === "providers") fetchProviders();
    else if (activeTab === "models") fetchModels();
    else if (activeTab === "analytics" || activeTab === "logs") fetchAnalytics();
    else if (activeTab === "collaborators") fetchCollaborators();
    setTimeout(() => setLoading(false), 300);
  };

  useEffect(() => {
    refreshActiveTab();
  }, [activeTab]);

  const handleSaveKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeKeyProvider) return;
    setSavingKey(true);
    try {
      await fetch("/api/admin/keys", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          providerId: activeKeyProvider.providerId,
          apiKey: inputKey.trim(),
        }),
      });
      setKeyModalOpen(false);
      setInputKey("");
      fetchKeys();
    } catch (e) {
      console.error(e);
    } finally {
      setSavingKey(false);
    }
  };

  const handleTestKey = async (providerId: string, providerName: string) => {
    setTestStatus((p) => ({ ...p, [providerId]: { status: "testing", message: "Pinging endpoint..." } }));
    try {
      const res = await fetch("/api/admin/keys", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          providerId,
          action: "test",
        }),
      });
      const data = await res.json();
      setTestStatus((p) => ({
        ...p,
        [providerId]: {
          status: data.status,
          message: data.message || "Test completed",
        },
      }));
    } catch (err: any) {
      setTestStatus((p) => ({
        ...p,
        [providerId]: {
          status: "auth_error",
          message: err.message,
        },
      }));
    }
  };

  const handleToggleUserRole = async (userId: string, currentRole: string) => {
    const newRole = currentRole === "admin" ? "user" : "admin";
    await fetch("/api/admin/users", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: userId, role: newRole }),
    });
    fetchUsers();
  };

  const handleToggleUserStatus = async (userId: string, currentStatus: string) => {
    const nextStatus = currentStatus === "suspended" ? "active" : "suspended";
    await fetch("/api/admin/users", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: userId, status: nextStatus }),
    });
    fetchUsers();
  };

  const handleAddCustomProvider = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProvName || !newProvSlug || !newProvUrl) return;
    setSavingProvider(true);
    try {
      await fetch("/api/admin/providers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newProvName,
          slug: newProvSlug,
          baseUrl: newProvUrl,
          defaultModelId: newProvModelId || `${newProvSlug}-v1`,
        }),
      });
      setProviderModalOpen(false);
      setNewProvName("");
      setNewProvSlug("");
      setNewProvUrl("");
      fetchProviders();
    } catch (e) {
      console.error(e);
    } finally {
      setSavingProvider(false);
    }
  };

  const handleInviteCollab = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCollabName || !newCollabEmail) return;
    try {
      await fetch("/api/admin/collaborators", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newCollabName,
          email: newCollabEmail,
          role: newCollabRole,
        }),
      });
      setCollabModalOpen(false);
      setNewCollabName("");
      setNewCollabEmail("");
      fetchCollaborators();
    } catch (e) {
      console.error(e);
    }
  };

  const handleResolveLog = async (logId: string, resolved: boolean) => {
    await fetch("/api/admin/analytics", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: logId, resolved: !resolved }),
    });
    fetchAnalytics();
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Admin Title Bar */}
      <div className="p-6 rounded-3xl glass-panel border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-xs font-semibold mb-2">
            <Shield className="w-3.5 h-3.5" />
            ONS AI Sovereign Governance Suite
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight">
            Administrator Control Center
          </h2>
          <p className="text-xs md:text-sm text-slate-400 mt-1">
            Manage multi-provider API keys, users, models, custom endpoints, analytics, and error logs.
          </p>
        </div>

        <button
          onClick={refreshActiveTab}
          disabled={loading}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 transition cursor-pointer self-start md:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          <span>Refresh Data</span>
        </button>
      </div>

      {/* Admin Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
        {[
          { id: "keys", label: "API Key Manager", icon: Key },
          { id: "users", label: "Users & Roles", icon: Users },
          { id: "providers", label: "Providers & Custom APIs", icon: Layers },
          { id: "models", label: "Models & Quotas", icon: Cpu },
          { id: "analytics", label: "Usage Analytics", icon: BarChart3 },
          { id: "logs", label: "System Error Logs", icon: AlertTriangle },
          { id: "collaborators", label: "Collaborators", icon: UserCheck },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                isActive
                  ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-500/20"
                  : "bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: API Key Manager (Requirement 8) */}
      {activeTab === "keys" && (
        <div className="rounded-3xl glass-panel p-6 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Key className="w-4 h-4 text-purple-400" />
                Custom API Provider Key Manager
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Keys are encrypted with AES-256-GCM at rest and never leaked to frontend code.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-3">Provider</th>
                  <th className="p-3">API Base URL</th>
                  <th className="p-3">Key Status</th>
                  <th className="p-3">Masked Key</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {keysList.map((k) => (
                  <tr key={k.providerId} className="hover:bg-slate-900/40 transition">
                    <td className="p-3 font-semibold text-white">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-purple-400" />
                        <span>{k.name}</span>
                      </div>
                    </td>
                    <td className="p-3 font-mono text-[11px] text-slate-400 truncate max-w-xs">
                      {k.baseUrl}
                    </td>
                    <td className="p-3">
                      {k.isConfigured ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-medium">
                          <CheckCircle2 className="w-3 h-3" />
                          Configured ({k.source})
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-800 text-slate-400 text-[10px] font-medium">
                          <XCircle className="w-3 h-3" />
                          Not Configured
                        </span>
                      )}
                    </td>
                    <td className="p-3 font-mono text-slate-300">
                      {k.maskedKey}
                    </td>
                    <td className="p-3 text-right space-x-2">
                      <button
                        onClick={() => handleTestKey(k.providerId, k.name)}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 text-[11px] font-medium transition cursor-pointer"
                      >
                        Test Ping
                      </button>
                      <button
                        onClick={() => {
                          setActiveKeyProvider(k);
                          setInputKey("");
                          setKeyModalOpen(true);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 text-[11px] font-medium transition cursor-pointer"
                      >
                        Edit Key
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Test Status Banners if any */}
          {Object.keys(testStatus).map((pId) => {
            const st = testStatus[pId];
            return (
              <div
                key={pId}
                className={`p-3 rounded-xl text-xs flex items-center justify-between ${
                  st.status === "connected"
                    ? "bg-emerald-500/10 border border-emerald-500/20 text-emerald-300"
                    : st.status === "testing"
                    ? "bg-slate-800 text-slate-300"
                    : "bg-rose-500/10 border border-rose-500/20 text-rose-300"
                }`}
              >
                <span>{st.message}</span>
                <button
                  onClick={() => setTestStatus((p) => {
                    const n = { ...p };
                    delete n[pId];
                    return n;
                  })}
                  className="text-slate-400 hover:text-white"
                >
                  ×
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 2: Users & Roles */}
      {activeTab === "users" && (
        <div className="rounded-3xl glass-panel p-6 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-cyan-400" />
              Registered Platform Users ({usersList.length})
            </h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-3">User</th>
                  <th className="p-3">Email</th>
                  <th className="p-3">Role</th>
                  <th className="p-3">Plan / Credits</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {usersList.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-900/40 transition">
                    <td className="p-3 font-semibold text-white">{u.name}</td>
                    <td className="p-3 text-slate-400 font-mono text-[11px]">{u.email}</td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          u.role === "admin"
                            ? "bg-purple-500/20 text-purple-300 border border-purple-500/30"
                            : "bg-slate-800 text-slate-300"
                        }`}
                      >
                        {u.role}
                      </span>
                    </td>
                    <td className="p-3 text-slate-300">
                      {u.plan} • {u.credits?.toLocaleString()} cr
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] ${
                          u.status === "active" ? "text-emerald-400" : "text-rose-400"
                        }`}
                      >
                        {u.status}
                      </span>
                    </td>
                    <td className="p-3 text-right space-x-2">
                      <button
                        onClick={() => handleToggleUserRole(u.id, u.role)}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] transition"
                      >
                        {u.role === "admin" ? "Demote to User" : "Make Admin"}
                      </button>
                      <button
                        onClick={() => handleToggleUserStatus(u.id, u.status)}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400 text-[11px] transition"
                      >
                        {u.status === "active" ? "Suspend" : "Activate"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: Providers & Custom APIs */}
      {activeTab === "providers" && (
        <div className="rounded-3xl glass-panel p-6 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-purple-400" />
              Connected Foundation Providers ({providersList.length})
            </h3>
            <button
              onClick={() => setProviderModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Custom Provider</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {providersList.map((p) => (
              <div
                key={p.id}
                className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-sm">{p.name}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                    {p.slug}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 line-clamp-2">{p.description}</p>
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                  <span>Models: {p.modelsCount}</span>
                  <span className={p.hasKey ? "text-emerald-400" : "text-slate-500"}>
                    {p.hasKey ? "Key Encrypted" : "No Key Set"}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: Models */}
      {activeTab === "models" && (
        <div className="rounded-3xl glass-panel p-6 border border-slate-800 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
            <Cpu className="w-4 h-4 text-cyan-400" />
            Configured AI Models ({modelsList.length})
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-3">Model Name</th>
                  <th className="p-3">Model ID</th>
                  <th className="p-3">Provider</th>
                  <th className="p-3">Context Window</th>
                  <th className="p-3">Capabilities</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {modelsList.map((m) => (
                  <tr key={m.id} className="hover:bg-slate-900/40">
                    <td className="p-3 font-semibold text-white">{m.name}</td>
                    <td className="p-3 font-mono text-[11px] text-purple-300">{m.modelId}</td>
                    <td className="p-3 text-slate-300">{m.providerName}</td>
                    <td className="p-3 text-slate-400 font-mono">
                      {(m.contextWindow / 1000).toLocaleString()}k tokens
                    </td>
                    <td className="p-3 text-slate-400 text-[10px]">
                      {m.supportsVision ? "Vision • " : ""}Streaming • {m.category}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: Usage Analytics */}
      {activeTab === "analytics" && analytics && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl glass-panel border border-slate-800 space-y-1">
              <span className="text-[11px] text-slate-400 uppercase tracking-wider">Total Requests</span>
              <div className="text-2xl font-black text-white">{analytics.summary?.totalRequests}</div>
            </div>
            <div className="p-5 rounded-2xl glass-panel border border-slate-800 space-y-1">
              <span className="text-[11px] text-slate-400 uppercase tracking-wider">Total Tokens</span>
              <div className="text-2xl font-black text-purple-400">
                {analytics.summary?.totalTokens?.toLocaleString()}
              </div>
            </div>
            <div className="p-5 rounded-2xl glass-panel border border-slate-800 space-y-1">
              <span className="text-[11px] text-slate-400 uppercase tracking-wider">Estimated Cost</span>
              <div className="text-2xl font-black text-emerald-400">${analytics.summary?.estimatedCost}</div>
            </div>
            <div className="p-5 rounded-2xl glass-panel border border-slate-800 space-y-1">
              <span className="text-[11px] text-slate-400 uppercase tracking-wider">Active Users</span>
              <div className="text-2xl font-black text-cyan-400">{analytics.summary?.totalUsers}</div>
            </div>
          </div>

          {/* Breakdown by Provider */}
          <div className="p-6 rounded-3xl glass-panel border border-slate-800 space-y-4">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">
              Token Ingestion Breakdown by Provider
            </h4>
            <div className="space-y-2">
              {Object.keys(analytics.providerStats || {}).map((pKey) => {
                const stat = analytics.providerStats[pKey];
                return (
                  <div key={pKey} className="space-y-1">
                    <div className="flex justify-between text-xs text-slate-300">
                      <span className="font-semibold uppercase">{pKey}</span>
                      <span>{stat.requests} requests • {stat.tokens?.toLocaleString()} tokens</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-purple-500 to-cyan-400 rounded-full"
                        style={{ width: `${Math.min(100, Math.max(10, (stat.tokens / 200000) * 100))}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: System Error Logs */}
      {activeTab === "logs" && analytics && (
        <div className="rounded-3xl glass-panel p-6 border border-slate-800 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            Audit & System Error Logs ({analytics.errorLogs?.length || 0})
          </h3>

          <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
            {(!analytics.errorLogs || analytics.errorLogs.length === 0) ? (
              <div className="text-xs text-slate-500 italic p-4 text-center">
                Clean system health. No active error logs recorded.
              </div>
            ) : (
              analytics.errorLogs.map((log: any) => (
                <div
                  key={log.id}
                  className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 text-xs flex items-start justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-purple-300 font-semibold">{log.source}</span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {new Date(log.createdAt).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-slate-300 mt-1 font-mono text-[11px]">{log.message}</p>
                  </div>
                  <button
                    onClick={() => handleResolveLog(log.id, log.resolved)}
                    className={`px-2 py-1 rounded text-[10px] font-medium shrink-0 transition ${
                      log.resolved
                        ? "bg-emerald-500/10 text-emerald-400"
                        : "bg-slate-800 hover:bg-slate-700 text-slate-300"
                    }`}
                  >
                    {log.resolved ? "Resolved" : "Mark Resolved"}
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB 7: Collaborators */}
      {activeTab === "collaborators" && (
        <div className="rounded-3xl glass-panel p-6 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-purple-400" />
              Team Collaborators & Admins ({collabsList.length})
            </h3>
            <button
              onClick={() => setCollabModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Collaborator</span>
            </button>
          </div>

          <div className="space-y-2">
            {collabsList.map((c) => (
              <div
                key={c.id}
                className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-semibold text-white">{c.name}</span>
                  <span className="text-slate-400 font-mono ml-2">({c.email})</span>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-400 font-mono text-[10px]">
                  {c.role}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Edit API Key Modal */}
      {keyModalOpen && activeKeyProvider && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 space-y-4">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-purple-400" />
              Configure {activeKeyProvider.name} API Key
            </h3>
            <p className="text-xs text-slate-400">
              Your key will be securely encrypted with AES-256-GCM and stored server-side.
            </p>

            <form onSubmit={handleSaveKey} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  API Key Secret
                </label>
                <input
                  type="password"
                  value={inputKey}
                  onChange={(e) => setInputKey(e.target.value)}
                  placeholder="sk-..."
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-white placeholder-slate-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setKeyModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingKey}
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold"
                >
                  {savingKey ? "Encrypting..." : "Save Key"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Custom Provider Modal */}
      {providerModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 space-y-4">
            <h3 className="text-lg font-bold text-white">Add Custom AI Provider</h3>
            <form onSubmit={handleAddCustomProvider} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Provider Name</label>
                <input
                  type="text"
                  required
                  value={newProvName}
                  onChange={(e) => setNewProvName(e.target.value)}
                  placeholder="e.g. vLLM Private Server"
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1">Provider Slug</label>
                <input
                  type="text"
                  required
                  value={newProvSlug}
                  onChange={(e) => setNewProvSlug(e.target.value)}
                  placeholder="e.g. vllm"
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1">API Base URL</label>
                <input
                  type="text"
                  required
                  value={newProvUrl}
                  onChange={(e) => setNewProvUrl(e.target.value)}
                  placeholder="e.g. https://ai.internal.corp/v1"
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1">Initial Model ID (Optional)</label>
                <input
                  type="text"
                  value={newProvModelId}
                  onChange={(e) => setNewProvModelId(e.target.value)}
                  placeholder="e.g. mistral-large-2407"
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setProviderModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingProvider}
                  className="px-4 py-2 rounded-xl bg-purple-600 text-white font-semibold"
                >
                  {savingProvider ? "Saving..." : "Add Provider"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Invite Collaborator Modal */}
      {collabModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 space-y-4">
            <h3 className="text-lg font-bold text-white">Add Team Collaborator</h3>
            <form onSubmit={handleInviteCollab} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={newCollabName}
                  onChange={(e) => setNewCollabName(e.target.value)}
                  placeholder="e.g. Taylor Smith"
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={newCollabEmail}
                  onChange={(e) => setNewCollabEmail(e.target.value)}
                  placeholder="taylor@company.com"
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1">Role</label>
                <select
                  value={newCollabRole}
                  onChange={(e) => setNewCollabRole(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white"
                >
                  <option value="collaborator">Collaborator</option>
                  <option value="admin">Administrator</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setCollabModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-purple-600 text-white font-semibold"
                >
                  Add Collaborator
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
