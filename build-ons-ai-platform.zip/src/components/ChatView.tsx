"use client";

import React, { useState, useEffect, useRef } from "react";
import {
  Send,
  Paperclip,
  Sparkles,
  Bot,
  User,
  Plus,
  Trash2,
  Cpu,
  Layers,
  FileText,
  AlertCircle,
  Copy,
  Check,
  ChevronDown,
} from "lucide-react";
import { MarkdownRenderer } from "./MarkdownRenderer";

interface ChatViewProps {
  conversations: any[];
  activeConversationId: string | null;
  onSelectConversation: (id: string) => void;
  onNewConversation: () => void;
  onDeleteConversation: (id: string) => void;
  onViewChange: (view: string) => void;
  currentUser: any;
}

export function ChatView({
  conversations,
  activeConversationId,
  onSelectConversation,
  onNewConversation,
  onDeleteConversation,
  onViewChange,
  currentUser,
}: ChatViewProps) {
  const [messages, setMessages] = useState<any[]>([]);
  const [inputContent, setInputContent] = useState("");
  const [loading, setLoading] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState("openai");
  const [selectedModel, setSelectedModel] = useState("gpt-4o");
  const [attachedFiles, setAttachedFiles] = useState<any[]>([]);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [modelDropdownOpen, setModelDropdownOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const modelOptions = [
    { provider: "openai", providerName: "OpenAI", modelId: "gpt-4o", modelName: "GPT-4o (Omni Intelligence)" },
    { provider: "openai", providerName: "OpenAI", modelId: "gpt-4o-mini", modelName: "GPT-4o Mini (Fast)" },
    { provider: "openai", providerName: "OpenAI", modelId: "o1-preview", modelName: "o1 Reasoning Engine" },
    { provider: "anthropic", providerName: "Anthropic", modelId: "claude-3-5-sonnet-20241022", modelName: "Claude 3.5 Sonnet (Coding & Nuance)" },
    { provider: "anthropic", providerName: "Anthropic", modelId: "claude-3-5-haiku-20241022", modelName: "Claude 3.5 Haiku" },
    { provider: "gemini", providerName: "Google Gemini", modelId: "gemini-1.5-pro", modelName: "Gemini 1.5 Pro (1M Context)" },
    { provider: "gemini", providerName: "Google Gemini", modelId: "gemini-2.0-flash", modelName: "Gemini 2.0 Flash" },
    { provider: "deepseek", providerName: "DeepSeek", modelId: "deepseek-chat", modelName: "DeepSeek Chat (V3)" },
    { provider: "deepseek", providerName: "DeepSeek", modelId: "deepseek-reasoner", modelName: "DeepSeek Reasoner (R1)" },
    { provider: "groq", providerName: "Groq", modelId: "llama-3.3-70b-versatile", modelName: "Llama 3.3 70B (Groq LPU)" },
    { provider: "openrouter", providerName: "OpenRouter", modelId: "openrouter/auto", modelName: "OpenRouter Auto-Routing" },
    { provider: "qwen", providerName: "Qwen (Alibaba)", modelId: "qwen-2.5-72b-instruct", modelName: "Qwen 2.5 72B Instruct" },
    { provider: "glm", providerName: "GLM (Zhipu)", modelId: "glm-4-plus", modelName: "GLM-4 Plus" },
    { provider: "minimax", providerName: "MiniMax", modelId: "abab6.5s-chat", modelName: "MiniMax abab6.5s" },
    { provider: "custom", providerName: "Custom Provider", modelId: "custom-model-v1", modelName: "Custom Private API" },
  ];

  // Fetch messages when activeConversationId changes
  useEffect(() => {
    if (!activeConversationId) {
      setMessages([]);
      return;
    }

    const fetchMessages = async () => {
      try {
        const res = await fetch(`/api/chat?conversationId=${activeConversationId}`);
        const data = await res.json();
        if (data.messages) {
          setMessages(data.messages);
        }
      } catch (err) {
        console.error("Failed to fetch messages:", err);
      }
    };

    fetchMessages();
  }, [activeConversationId]);

  // Scroll to bottom on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputContent.trim() || loading) return;

    const userText = inputContent.trim();
    setInputContent("");

    // Optimistic user message
    const tempUserMsg = {
      id: `temp-${Date.now()}`,
      role: "user",
      content: userText,
      attachments: attachedFiles.length > 0 ? JSON.stringify(attachedFiles) : null,
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, tempUserMsg]);
    setAttachedFiles([]);
    setLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conversationId: activeConversationId || undefined,
          content: userText,
          providerSlug: selectedProvider,
          modelId: selectedModel,
          attachments: attachedFiles,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to send message");

      // If new conversation was created on the fly
      if (!activeConversationId && data.conversationId) {
        onSelectConversation(data.conversationId);
      }

      setMessages((prev) => [
        ...prev.filter((m) => m.id !== tempUserMsg.id),
        data.userMessage,
        data.assistantMessage,
      ]);
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: "assistant",
          content: `⚠️ Error executing request: ${err.message}. Please check your provider configuration.`,
          createdAt: new Date().toISOString(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingFile(true);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (data.success && data.file) {
        setAttachedFiles((prev) => [...prev, data.file]);
      }
    } catch (err) {
      console.error("Upload error:", err);
    } finally {
      setUploadingFile(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handlePromptSuggestion = (prompt: string) => {
    setInputContent(prompt);
  };

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col glass-panel rounded-3xl border border-slate-800 overflow-hidden shadow-2xl relative">
      {/* Top Header: Model Switcher & New Chat */}
      <div className="h-14 px-4 border-b border-slate-800/80 bg-slate-900/60 flex items-center justify-between shrink-0">
        {/* Model Selector dropdown */}
        <div className="relative">
          <button
            onClick={() => setModelDropdownOpen(!modelDropdownOpen)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 text-xs font-semibold text-white transition cursor-pointer"
          >
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
            <span>
              {modelOptions.find((m) => m.modelId === selectedModel)?.modelName || selectedModel}
            </span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>

          {modelDropdownOpen && (
            <div className="absolute left-0 mt-2 w-72 max-h-80 overflow-y-auto rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl p-1.5 z-50 text-xs">
              <div className="px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Select Active AI Provider & Model
              </div>
              {modelOptions.map((opt) => (
                <button
                  key={opt.modelId}
                  onClick={() => {
                    setSelectedProvider(opt.provider);
                    setSelectedModel(opt.modelId);
                    setModelDropdownOpen(false);
                  }}
                  className={`w-full text-left px-2.5 py-2 rounded-lg flex flex-col transition cursor-pointer ${
                    selectedModel === opt.modelId
                      ? "bg-purple-600/20 text-purple-300 font-semibold border border-purple-500/30"
                      : "text-slate-300 hover:bg-slate-800/80"
                  }`}
                >
                  <span className="font-medium text-white">{opt.modelName}</span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Provider: {opt.providerName}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right actions: New Chat */}
        <div className="flex items-center gap-2">
          <button
            onClick={onNewConversation}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/30 text-purple-300 text-xs font-medium transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">New Chat</span>
          </button>
        </div>
      </div>

      {/* Message Stream */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-5">
        {messages.length === 0 ? (
          /* Empty Chat State */
          <div className="h-full flex flex-col items-center justify-center text-center p-6 max-w-lg mx-auto space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-600 to-cyan-500 flex items-center justify-center shadow-xl shadow-purple-500/20">
              <Sparkles className="w-7 h-7 text-white" />
            </div>

            <div>
              <h3 className="text-xl font-extrabold text-white tracking-tight">
                ONS AI Multimodal Chat Studio
              </h3>
              <p className="text-xs md:text-sm text-slate-400 mt-1 leading-relaxed">
                Interact with OpenAI, Claude, Gemini, DeepSeek, Groq, and custom API endpoints. Attach files, write code, or prompt deep research.
              </p>
            </div>

            {/* Prompt suggestions */}
            <div className="w-full space-y-2 pt-2">
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                Try a prompt suggestion:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-left">
                {[
                  "Architect a Next.js 15 App Router microservice with Redis cache and auth guards",
                  "Compare mathematical reasoning depth of DeepSeek-R1 vs OpenAI o1 with benchmarks",
                  "Write an investor pitch email for a Series A generative AI cloud platform",
                  "Explain vector database indexing and HNSW algorithms in high technical detail",
                ].map((prompt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handlePromptSuggestion(prompt)}
                    className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800/80 text-xs text-slate-300 hover:text-white transition leading-snug cursor-pointer"
                  >
                    "{prompt}"
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          messages.map((msg, idx) => {
            const isUser = msg.role === "user";
            let parsedAttachments = [];
            if (msg.attachments) {
              try {
                parsedAttachments = JSON.parse(msg.attachments);
              } catch (e) {}
            }

            return (
              <div
                key={msg.id || idx}
                className={`flex gap-3 md:gap-4 ${isUser ? "justify-end" : "justify-start"} animate-fadeIn`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-600 to-cyan-600 flex items-center justify-center shrink-0 shadow-md">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] md:max-w-[80%] rounded-2xl p-4 shadow-md ${
                    isUser
                      ? "bg-purple-600/20 border border-purple-500/30 text-white rounded-tr-sm"
                      : "bg-slate-900/90 border border-slate-800 text-slate-200 rounded-tl-sm"
                  }`}
                >
                  {/* Attachments preview */}
                  {parsedAttachments && parsedAttachments.length > 0 && (
                    <div className="mb-2 flex flex-wrap gap-1.5">
                      {parsedAttachments.map((f: any, fIdx: number) => (
                        <div
                          key={fIdx}
                          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-950/80 border border-slate-800 text-[11px] text-cyan-300 font-mono"
                        >
                          <FileText className="w-3 h-3" />
                          <span>{f.fileName || "attachment"}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {isUser ? (
                    <p className="text-sm md:text-base leading-relaxed whitespace-pre-wrap">
                      {msg.content}
                    </p>
                  ) : (
                    <MarkdownRenderer content={msg.content} />
                  )}

                  {/* Model signature for assistant */}
                  {!isUser && msg.model && (
                    <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500">
                      <span>Model: {msg.model}</span>
                      <button
                        onClick={() => navigator.clipboard.writeText(msg.content)}
                        className="hover:text-slate-300 transition flex items-center gap-1"
                        title="Copy response"
                      >
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </button>
                    </div>
                  )}
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center shrink-0 border border-slate-700">
                    <User className="w-4 h-4 text-purple-300" />
                  </div>
                )}
              </div>
            );
          })
        )}

        {/* Loading typing bubble */}
        {loading && (
          <div className="flex gap-3 items-center animate-fadeIn">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-600 to-cyan-600 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className="px-4 py-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-purple-400 animate-bounce" />
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce [animation-delay:0.2s]" />
              <span className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce [animation-delay:0.4s]" />
              <span className="text-xs text-slate-400 font-mono ml-2">
                ONS Engine processing with {selectedModel}...
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Tray */}
      <div className="p-3 md:p-4 border-t border-slate-800 bg-slate-900/80 shrink-0 space-y-2">
        {/* Attached files chips */}
        {attachedFiles.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {attachedFiles.map((file, fIdx) => (
              <div
                key={fIdx}
                className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-800 border border-slate-700 text-xs text-cyan-300"
              >
                <FileText className="w-3.5 h-3.5" />
                <span className="truncate max-w-xs">{file.fileName}</span>
                <button
                  type="button"
                  onClick={() => setAttachedFiles((prev) => prev.filter((_, i) => i !== fIdx))}
                  className="text-slate-400 hover:text-rose-400 ml-1"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}

        <form onSubmit={handleSendMessage} className="flex items-end gap-2">
          {/* File attachment hidden input */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            className="hidden"
            accept=".txt,.md,.pdf,.json,.ts,.tsx,.py,.js"
          />

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploadingFile}
            className="p-3 rounded-2xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
            title="Attach file (PDF, Markdown, Code, Text)"
          >
            {uploadingFile ? (
              <span className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin inline-block" />
            ) : (
              <Paperclip className="w-4 h-4" />
            )}
          </button>

          <div className="flex-1 relative">
            <textarea
              rows={1}
              value={inputContent}
              onChange={(e) => setInputContent(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder={`Message ${selectedModel}... (Press Enter to send, Shift+Enter for new line)`}
              className="w-full px-4 py-3 rounded-2xl bg-slate-950/80 border border-slate-800 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-purple-500 resize-none transition"
            />
          </div>

          <button
            type="submit"
            disabled={loading || !inputContent.trim()}
            className="p-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:opacity-90 disabled:opacity-40 text-white shadow-lg shadow-purple-500/20 transition cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
